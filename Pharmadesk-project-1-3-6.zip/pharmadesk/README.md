# Pharmadesk

Pharmadesk is a pharmacy knowledge-base learning app.

## Version 1.3.6 — branding and Home refresh

- Updated the in-app brand mark and installed-app icons with the supplied PharmaDesk logo.
- Added the supplied pharmacist image as the Home Page welcome banner with “Welcome to PharmaDesk. Unlock your potential.”
- Moved About PharmaDesk out of Settings into its own workplace section and added an About summary on Home.
- Updated the service-worker cache version so devices can fetch the new branding assets.

## Unit II update (v1.3.5)

Unit II now contains study-note pages for Classes 3–7:
- Class 3: Introduction to the Autonomic Nervous System
- Class 4: Cholinergic Agonists
- Class 5: Cholinergic Antagonists
- Class 6: Adrenergic Agonists
- Class 7: Adrenergic Antagonists

Each note is organised using the same seven study headings: indications, groups/examples, mechanism of action, uses, side effects/adverse effects, contraindications/precautions, and drug interactions. Supporting diagrams and source-list images are stored in `public/unit2/`.

Drug-specific clinical information should be checked against current product information and trusted clinical references. The app is an educational resource, not a prescribing tool.

## Development

```bash
npm install
npm run dev
npm run build
```
