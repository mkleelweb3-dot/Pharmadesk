import { useEffect, useMemo, useState } from 'react';
import { BookOpen, ChevronRight, Heart, Languages, Menu, Pill, Search, ShieldCheck, Wifi, WifiOff, X, ArrowLeft } from 'lucide-react';
import { drugClasses, type DrugClass } from './data';
import './style.css';

const systems = [...new Set(drugClasses.map(d => d.system))];
const haSystem: Record<string,string> = {
  'Gastrointestinal':'Tsarin narkar da abinci','Respiratory':'Tsarin numfashi','Cardiovascular':'Tsarin zuciya da jijiyoyin jini',
  'Nervous system':'Tsarin jijiyoyi','Endocrine':'Tsarin hormones','Reproductive':'Tsarin haihuwa',
  'Musculoskeletal':'Tsarin ƙashi da tsoka','Anti-infectives':'Magungunan yaƙi da ƙwayoyin cuta',
  'Hematology':'Tsarin jini','Dermatology':'Fannin fata','Ophthalmology & ENT':'Ido, kunne, hanci da maƙogwaro',
  'Renal & Urology':'Koda da hanyoyin fitsari','Immunology & Oncology':'Garkuwar jiki da kansa'
};
function App() {
  const [lang,setLang] = useState<'en'|'ha'>(() => (localStorage.getItem('pd-lang') as 'en'|'ha') || 'ha');
  const [search,setSearch] = useState('');
  const [system,setSystem] = useState('All');
  const [detail,setDetail] = useState<DrugClass|null>(null);
  const [saved,setSaved] = useState<string[]>(() => JSON.parse(localStorage.getItem('pd-saved') || '[]'));
  const [onlySaved,setOnlySaved] = useState(false);
  const [online,setOnline] = useState(navigator.onLine);
  const [navOpen,setNavOpen] = useState(false);
  const ha = lang === 'ha';
  useEffect(() => { localStorage.setItem('pd-lang',lang); },[lang]);
  useEffect(() => { localStorage.setItem('pd-saved',JSON.stringify(saved)); },[saved]);
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    addEventListener('online',update); addEventListener('offline',update);
    if ('serviceWorker' in navigator) addEventListener('load',() => navigator.serviceWorker.register('/sw.js').catch(()=>{}));
    return () => { removeEventListener('online',update); removeEventListener('offline',update); };
  },[]);
  const results = useMemo(() => drugClasses.filter(d => {
    const q = search.toLowerCase();
    return (system === 'All' || d.system === system) && (!onlySaved || saved.includes(d.id)) &&
      [d.name,d.nameHa,d.system,d.description,...d.examples,...d.subgroups].join(' ').toLowerCase().includes(q);
  }),[search,system,onlySaved,saved]);
  const toggleSave = (id:string) => setSaved(old => old.includes(id) ? old.filter(x=>x!==id) : [...old,id]);
  const title = (d:DrugClass) => ha ? d.nameHa : d.name;
  const sysTitle = (s:string) => ha ? (haSystem[s] || s) : s;
  const t = (en:string,haText:string) => ha ? haText : en;
  return <div className="shell">
    <header className="topbar">
      <button className="brand" onClick={()=>{setDetail(null);setSystem('All');setOnlySaved(false);}}><span className="logo"><Pill/></span><span><b>pharmadesk</b><small>PHARMACY KNOWLEDGE BASE</small></span></button>
      <div className="top-actions">
        <span className={online?'status online':'status offline'}>{online?<Wifi size={15}/>:<WifiOff size={15}/>} {online?t('Online','Akwai internet') : t('Offline ready','A shirye offline')}</span>
        <button className="lang" onClick={()=>setLang(ha?'en':'ha')}><Languages size={16}/>{ha?'English':'Hausa'}</button>
        <button className="saved-head" onClick={()=>{setOnlySaved(!onlySaved);setDetail(null);}}><Heart size={16}/><span>{t('Saved','Abubuwan da aka ajiye')}</span> {saved.length}</button>
        <button className="hamb" onClick={()=>setNavOpen(!navOpen)} aria-label="Toggle navigation">{navOpen?<X/>:<Menu/>}</button>
      </div>
    </header>
    <div className="body">
      <aside className={navOpen?'sidebar open':'sidebar'}>
        <div className="nav-label">{t('LIBRARY','TASKAR BAYANI')}</div>
        <button className={system==='All'&&!onlySaved?'nav-item active':'nav-item'} onClick={()=>{setSystem('All');setOnlySaved(false);setDetail(null);setNavOpen(false);}}><BookOpen size={16}/>{t('All drug classes','Dukkan drug classes')}<span>{drugClasses.length}</span></button>
        <div className="nav-label systems-label">{t('BODY SYSTEMS','TSARIN JIKI')}</div>
        {systems.map(s=><button key={s} className={system===s&&!onlySaved?'nav-item active':'nav-item'} onClick={()=>{setSystem(s);setOnlySaved(false);setDetail(null);setNavOpen(false);}}><i/>{sysTitle(s)}<span>{drugClasses.filter(d=>d.system===s).length}</span></button>)}
        <div className="safety-note"><ShieldCheck size={17}/><div><b>{t('Study reference','Bayanan karatu')}</b><p>{t('Educational use only. Verify clinical decisions with trusted references.','Don karatu ne kawai. Tabbatar da shawarar asibiti daga sahihan littattafai da jagorori.')}</p></div></div>
      </aside>
      <main className="main">
        {detail ? <section className="detail">
          <button className="back" onClick={()=>setDetail(null)}><ArrowLeft size={16}/>{t('Back to library','Komawa jerin magunguna')}</button>
          <div className="kicker">{sysTitle(detail.system)}</div>
          <div className="detail-title"><div><h1>{title(detail)}</h1><p>{ha?detail.descriptionHa:detail.description}</p></div><button className={saved.includes(detail.id)?'heart saved':'heart'} onClick={()=>toggleSave(detail.id)}><Heart fill={saved.includes(detail.id)?'currentColor':'none'}/></button></div>
          <div className="panel"><h3>{t('Generic drug examples','Misalan sunayen magunguna na generic')}</h3><div className="drug-grid">{detail.examples.map(x=><div className="drug" key={x}><Pill size={16}/>{x}</div>)}</div></div>
          <div className="panel"><h3>{t('Subclasses / related groups','Ƙananan rukuni / masu alaƙa')}</h3><div className="tags">{detail.subgroups.map(x=><span key={x}>{x}</span>)}</div></div>
          <div className="warning"><ShieldCheck size={18}/><p>{t('Educational classification only. A medicine may belong to more than one class and may have multiple indications. This app does not provide dosing, diagnosis or prescribing advice.','Rarrabewa ce don ilimi kawai. Magani na iya kasancewa a rukuni fiye da ɗaya kuma yana iya samun amfani daban-daban. Wannan manhaja ba ta bayar da dose, diagnosis ko shawarar rubuta magani.')}</p></div>
        </section> : <>
          <section className="hero"><div className="hero-copy"><div className="eyebrow">● {t('YOUR PHARMACY KNOWLEDGE BASE','TASKAR ILIMIN PHARMACY')}</div><h1>{t('Understand drugs.','Fahimci magunguna.')}<br/><em>{t('System by system.','Tsari bayan tsari.')}</em></h1><p>{t('Explore therapeutic classes, understand their actions and revise generic drug examples — in Hausa and English, even offline.','Binciki drug classes, fahimci ayyukansu, ka koyi misalan generic drugs — da Hausa da Turanci, ko babu internet.')}</p></div><div className="hero-icon"><Pill size={58}/></div></section>
          <div className="section-head"><div><div className="kicker">{onlySaved?t('YOUR PERSONAL LIST','JERINKA'):t('EXPLORE THE LIBRARY','BINCIKI TASKAR BAYANI')}</div><h2>{onlySaved?t('Saved drug classes','Drug classes da aka ajiye'):system==='All'?t('Drug classes','Drug classes'):sysTitle(system)}</h2><p>{results.length} {t('classes','rukuni')}</p></div></div>
          <div className="tools"><label className="search"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={t('Search drug, class or body system...','Nemo drug, class ko tsarin jiki...')}/></label><select value={system} onChange={e=>{setSystem(e.target.value);setOnlySaved(false);}}><option value="All">{t('All systems','Dukkan systems')}</option>{systems.map(s=><option key={s} value={s}>{sysTitle(s)}</option>)}</select></div>
          {results.length?<div className="grid">{results.map(d=><article key={d.id} className="card" onClick={()=>setDetail(d)}><div className="card-top"><span>{sysTitle(d.system)}</span><button onClick={e=>{e.stopPropagation();toggleSave(d.id);}} aria-label="Save"><Heart size={17} fill={saved.includes(d.id)?'currentColor':'none'}/></button></div><h3>{title(d)}</h3><p>{ha?d.descriptionHa:d.description}</p><div className="examples"><small>{t('EXAMPLES','MISALAI')}</small>{d.examples.slice(0,3).join(' · ')}{d.examples.length>3?' +':''}</div><div className="card-foot">{d.examples.length} {t('examples','misalai')}<b>{t('Explore','Duba')} <ChevronRight size={14}/></b></div></article>)}</div>:<div className="empty"><Search size={30}/><h3>{t('No matching classes','Ba a sami rukuni mai dacewa ba')}</h3><p>{t('Try another keyword or clear the filters.','Gwada wata kalma ko cire filters.')}</p><button onClick={()=>{setSearch('');setSystem('All');setOnlySaved(false);}}> {t('Clear filters','Cire filters')}</button></div>}
        </>}
        <footer><span>PHARMADESK · {t('LEARN WITH CLARITY','ILIMI CIKIN SAUƘI')}</span><span>{t('Educational reference · Not a prescribing tool','Bayanan ilimi · Ba kayan rubuta magani ba')}</span></footer>
      </main>
    </div>
  </div>;
}
export default App;
