# Pharmadesk

Bilingual (Hausa + English), offline-first pharmacy drug-classification reference.

## Run locally
1. Install Node.js 20 or later.
2. In this folder run `npm install`.
3. Run `npm run dev` to preview locally.
4. Run `npm run build` to create the production build in `dist/`.

## Offline support
The app registers a service worker (`public/sw.js`) and caches the app shell and same-origin assets after the first successful visit. Serve over HTTPS (or localhost) for service-worker support. For a reliable first offline launch, open the app once while online and allow it to finish loading before disconnecting.

## Data model
`src/data.ts` contains the drug-class catalogue. Each entry has:
- English and Hausa system names
- English and Hausa class names
- English and Hausa educational descriptions
- generic-name examples
- subclasses / related groups

Add or edit entries in `src/data.ts`. The interface reads the catalogue dynamically.

## Important medical-content limitation
This is an educational taxonomy starter, not a complete or clinically validated national formulary. Classifications can overlap; examples are non-exhaustive and may vary by guideline, indication, country, and availability. Review the catalogue against current authoritative references and a registered pharmacist / clinical pharmacologist before public or clinical use. No doses, treatment recommendations, diagnosis, or prescribing instructions are included.

## Publish
Push this folder to a GitHub repository, then connect that repository to a static hosting provider (for example GitHub Pages, Netlify, or Vercel). Configure the build command as `npm run build` and output directory as `dist`. Service workers require HTTPS in production.
