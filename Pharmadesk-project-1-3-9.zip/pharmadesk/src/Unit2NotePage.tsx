import { unit2Notes } from './unit2Notes';
import { BookOpen, Image as ImageIcon, ShieldAlert } from 'lucide-react';

export function Unit2NotePage({number,onBack}:{number:number;onBack:()=>void}) {
  const note=unit2Notes[number];
  if(!note) return null;
  return <section className="chapter-detail unit-note-page">
    <button className="back" onClick={onBack}>← Back to units</button>
    <div className="unit-note-kicker">UNIT II · DRUGS AFFECTING THE AUTONOMIC NERVOUS SYSTEM</div>
    <div className="unit-note-heading"><span>CLASS {note.number}</span><h1>{note.title}</h1><p>{note.overview}</p></div>
    {note.image && <figure className="unit-note-figure"><img src={note.image} alt={note.imageAlt || note.title} loading="lazy"/><figcaption><ImageIcon size={13}/> Educational illustration · Review the written notes for clinical details.</figcaption></figure>}
    {note.sections.map((section,index)=><section className="unit-note-section" key={section.title}>
      <h2><span>{index+1}</span>{section.title}</h2>
      {section.points&&<ul>{section.points.map((point,i)=><li key={i}>{point}</li>)}</ul>}
      {section.groups?.map(group=><div className="unit-note-group" key={group.title}><h3>{group.title}</h3><ul>{group.items.map((item,i)=><li key={i}>{item}</li>)}</ul></div>)}
      {section.table&&<div className="unit-note-table-wrap"><table className="unit-note-table"><tbody>{section.table.map((row,i)=><tr key={i}><th>{row.left}</th><td>{row.right}</td></tr>)}</tbody></table></div>}
    </section>)}
    <div className="unit-note-warning"><ShieldAlert size={17}/><p><b>Educational reference only.</b> These concise notes support study and do not replace current prescribing information, clinical guidelines or professional judgement. Confirm drug-specific contraindications, doses and interactions from trusted references.</p></div>
    <div className="unit-note-footer"><BookOpen size={15}/> Pharmadesk · Unit II · Class {note.number}</div>
  </section>;
}
