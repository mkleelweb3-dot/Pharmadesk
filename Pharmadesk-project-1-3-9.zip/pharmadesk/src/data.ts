export type DrugClass = {
  id: string; system: string; systemHa: string; name: string; nameHa: string;
  description: string; descriptionHa: string; examples: string[]; subgroups: string[];
};
export const drugClasses: DrugClass[] = [
  {
    "id": "class-001",
    "system": "Gastrointestinal",
    "systemHa": "Gastrointestinal",
    "name": "Antacids",
    "nameHa": "Magungunan rage acid",
    "description": "Neutralise gastric acid in the stomach.",
    "descriptionHa": "Suna rage kaifin acid a ciki.",
    "examples": [
      "Aluminium hydroxide",
      "Magnesium hydroxide",
      "Calcium carbonate",
      "Sodium bicarbonate"
    ],
    "subgroups": [
      "Aluminium salts",
      "Magnesium salts",
      "Calcium salts"
    ]
  },
  {
    "id": "class-002",
    "system": "Gastrointestinal",
    "systemHa": "Gastrointestinal",
    "name": "Proton pump inhibitors (PPIs)",
    "nameHa": "Masu hana proton pump",
    "description": "Reduce gastric acid secretion by inhibiting the proton pump.",
    "descriptionHa": "Suna rage samar da acid ta hanyar hana proton pump.",
    "examples": [
      "Omeprazole",
      "Esomeprazole",
      "Lansoprazole",
      "Pantoprazole",
      "Rabeprazole"
    ],
    "subgroups": [
      "PPIs"
    ]
  },
  {
    "id": "class-003",
    "system": "Gastrointestinal",
    "systemHa": "Gastrointestinal",
    "name": "H2-receptor antagonists",
    "nameHa": "Masu hana H2 receptor",
    "description": "Reduce gastric acid secretion through histamine H2 blockade.",
    "descriptionHa": "Suna rage samar da acid ta hanyar toshe H2 receptor.",
    "examples": [
      "Famotidine",
      "Cimetidine",
      "Nizatidine"
    ],
    "subgroups": [
      "H2 blockers"
    ]
  },
  {
    "id": "class-004",
    "system": "Gastrointestinal",
    "systemHa": "Gastrointestinal",
    "name": "Antiemetics",
    "nameHa": "Magungunan tashin zuciya da amai",
    "description": "Prevent or relieve nausea and vomiting.",
    "descriptionHa": "Ana amfani da su wajen rage tashin zuciya da amai.",
    "examples": [
      "Ondansetron",
      "Metoclopramide",
      "Domperidone",
      "Prochlorperazine"
    ],
    "subgroups": [
      "5-HT3 antagonists",
      "Dopamine antagonists"
    ]
  },
  {
    "id": "class-005",
    "system": "Gastrointestinal",
    "systemHa": "Gastrointestinal",
    "name": "Laxatives",
    "nameHa": "Magungunan bayan gida",
    "description": "Promote bowel evacuation and relieve constipation.",
    "descriptionHa": "Suna taimakawa fitar bayan gida da rage maƙarƙashiya.",
    "examples": [
      "Lactulose",
      "Bisacodyl",
      "Senna",
      "Macrogol",
      "Psyllium"
    ],
    "subgroups": [
      "Bulk-forming",
      "Osmotic",
      "Stimulant"
    ]
  },
  {
    "id": "class-006",
    "system": "Gastrointestinal",
    "systemHa": "Gastrointestinal",
    "name": "Antidiarrhoeals",
    "nameHa": "Magungunan gudawa",
    "description": "Reduce diarrhoea symptoms or manage specific causes.",
    "descriptionHa": "Ana amfani da su wajen rage gudawa ko kula da wasu dalilanta.",
    "examples": [
      "Loperamide",
      "Bismuth subsalicylate",
      "Racecadotril"
    ],
    "subgroups": [
      "Antimotility",
      "Antisecretory"
    ]
  },
  {
    "id": "class-007",
    "system": "Respiratory",
    "systemHa": "Respiratory",
    "name": "Beta-2 agonist bronchodilators",
    "nameHa": "Masu buɗe hanyoyin numfashi (Beta-2)",
    "description": "Relax bronchial smooth muscle to improve airflow.",
    "descriptionHa": "Suna sassauta tsokokin hanyoyin numfashi domin iska ta ratsa.",
    "examples": [
      "Salbutamol",
      "Terbutaline",
      "Salmeterol",
      "Formoterol"
    ],
    "subgroups": [
      "SABA",
      "LABA"
    ]
  },
  {
    "id": "class-008",
    "system": "Respiratory",
    "systemHa": "Respiratory",
    "name": "Inhaled corticosteroids",
    "nameHa": "Corticosteroids na shaƙa",
    "description": "Reduce airway inflammation in obstructive airway disease.",
    "descriptionHa": "Suna rage kumburin hanyoyin numfashi idan an shaƙe su.",
    "examples": [
      "Beclometasone",
      "Budesonide",
      "Fluticasone",
      "Mometasone"
    ],
    "subgroups": [
      "Inhaled glucocorticoids"
    ]
  },
  {
    "id": "class-009",
    "system": "Respiratory",
    "systemHa": "Respiratory",
    "name": "Antihistamines",
    "nameHa": "Magungunan allergy",
    "description": "Block histamine receptors and relieve allergic symptoms.",
    "descriptionHa": "Suna toshe histamine domin rage alamomin allergy.",
    "examples": [
      "Cetirizine",
      "Loratadine",
      "Fexofenadine",
      "Chlorpheniramine",
      "Diphenhydramine"
    ],
    "subgroups": [
      "First-generation",
      "Second-generation"
    ]
  },
  {
    "id": "class-010",
    "system": "Respiratory",
    "systemHa": "Respiratory",
    "name": "Mucolytics",
    "nameHa": "Masu rage kaurin majina",
    "description": "Help reduce mucus viscosity for easier clearance.",
    "descriptionHa": "Suna rage kaurin majina domin fitar da ita cikin sauƙi.",
    "examples": [
      "Acetylcysteine",
      "Carbocisteine",
      "Bromhexine",
      "Ambroxol"
    ],
    "subgroups": [
      "Mucus-modifying agents"
    ]
  },
  {
    "id": "class-011",
    "system": "Cardiovascular",
    "systemHa": "Cardiovascular",
    "name": "ACE inhibitors",
    "nameHa": "Masu hana ACE",
    "description": "Inhibit angiotensin-converting enzyme.",
    "descriptionHa": "Suna hana aikin angiotensin-converting enzyme.",
    "examples": [
      "Lisinopril",
      "Enalapril",
      "Ramipril",
      "Captopril",
      "Perindopril"
    ],
    "subgroups": [
      "ACE inhibitors"
    ]
  },
  {
    "id": "class-012",
    "system": "Cardiovascular",
    "systemHa": "Cardiovascular",
    "name": "Angiotensin II receptor blockers (ARBs)",
    "nameHa": "Masu hana angiotensin receptor",
    "description": "Block angiotensin II type 1 receptors.",
    "descriptionHa": "Suna toshe angiotensin II type 1 receptors.",
    "examples": [
      "Losartan",
      "Valsartan",
      "Candesartan",
      "Irbesartan",
      "Telmisartan"
    ],
    "subgroups": [
      "ARBs"
    ]
  },
  {
    "id": "class-013",
    "system": "Cardiovascular",
    "systemHa": "Cardiovascular",
    "name": "Beta blockers",
    "nameHa": "Masu hana beta receptor",
    "description": "Block beta-adrenergic receptors and reduce cardiac workload.",
    "descriptionHa": "Suna toshe beta receptors tare da rage aikin zuciya.",
    "examples": [
      "Atenolol",
      "Bisoprolol",
      "Metoprolol",
      "Propranolol",
      "Carvedilol"
    ],
    "subgroups": [
      "Cardioselective",
      "Non-selective"
    ]
  },
  {
    "id": "class-014",
    "system": "Cardiovascular",
    "systemHa": "Cardiovascular",
    "name": "Calcium channel blockers",
    "nameHa": "Masu hana calcium channel",
    "description": "Reduce calcium entry into vascular smooth muscle or cardiac cells.",
    "descriptionHa": "Suna rage shigar calcium cikin wasu ƙwayoyin tsoka da zuciya.",
    "examples": [
      "Amlodipine",
      "Nifedipine",
      "Verapamil",
      "Diltiazem"
    ],
    "subgroups": [
      "Dihydropyridines",
      "Non-dihydropyridines"
    ]
  },
  {
    "id": "class-015",
    "system": "Cardiovascular",
    "systemHa": "Cardiovascular",
    "name": "Diuretics",
    "nameHa": "Magungunan fitar da ruwa",
    "description": "Increase renal excretion of sodium and water.",
    "descriptionHa": "Suna ƙara fitar sodium da ruwa ta fitsari.",
    "examples": [
      "Furosemide",
      "Hydrochlorothiazide",
      "Indapamide",
      "Spironolactone",
      "Amiloride"
    ],
    "subgroups": [
      "Loop",
      "Thiazide-like",
      "Potassium-sparing"
    ]
  },
  {
    "id": "class-016",
    "system": "Cardiovascular",
    "systemHa": "Cardiovascular",
    "name": "Statins",
    "nameHa": "Magungunan rage cholesterol",
    "description": "Inhibit HMG-CoA reductase and lower LDL cholesterol.",
    "descriptionHa": "Suna hana HMG-CoA reductase domin rage LDL cholesterol.",
    "examples": [
      "Atorvastatin",
      "Simvastatin",
      "Rosuvastatin",
      "Pravastatin"
    ],
    "subgroups": [
      "HMG-CoA reductase inhibitors"
    ]
  },
  {
    "id": "class-017",
    "system": "Cardiovascular",
    "systemHa": "Cardiovascular",
    "name": "Antiarrhythmics",
    "nameHa": "Magungunan bugun zuciya mara tsari",
    "description": "Modify cardiac electrical activity to manage selected arrhythmias.",
    "descriptionHa": "Suna canza siginar lantarki ta zuciya wajen kula da wasu arrhythmias.",
    "examples": [
      "Amiodarone",
      "Adenosine",
      "Lidocaine",
      "Flecainide",
      "Sotalol"
    ],
    "subgroups": [
      "Class I",
      "Class II",
      "Class III",
      "Class IV"
    ]
  },
  {
    "id": "class-018",
    "system": "Nervous system",
    "systemHa": "Nervous system",
    "name": "Non-opioid analgesics",
    "nameHa": "Magungunan rage zafi marasa opioid",
    "description": "Relieve pain through non-opioid mechanisms.",
    "descriptionHa": "Suna rage zafi ba tare da tsarin opioid ba.",
    "examples": [
      "Paracetamol",
      "Metamizole"
    ],
    "subgroups": [
      "Simple analgesics"
    ]
  },
  {
    "id": "class-019",
    "system": "Nervous system",
    "systemHa": "Nervous system",
    "name": "Opioid analgesics",
    "nameHa": "Magungunan rage zafi na opioid",
    "description": "Act on opioid receptors to produce analgesia; some carry dependence and respiratory risks.",
    "descriptionHa": "Suna aiki a opioid receptors; wasu na da haɗarin dogaro da matsalar numfashi.",
    "examples": [
      "Morphine",
      "Tramadol",
      "Codeine",
      "Oxycodone",
      "Fentanyl"
    ],
    "subgroups": [
      "Full agonists",
      "Partial agonists"
    ]
  },
  {
    "id": "class-020",
    "system": "Nervous system",
    "systemHa": "Nervous system",
    "name": "Antidepressants",
    "nameHa": "Magungunan depression",
    "description": "Modify neurotransmission and are used in depression and selected conditions.",
    "descriptionHa": "Suna shafar sadarwar sinadarai a kwakwalwa; ana amfani da su a wasu yanayi.",
    "examples": [
      "Fluoxetine",
      "Sertraline",
      "Amitriptyline",
      "Venlafaxine",
      "Mirtazapine"
    ],
    "subgroups": [
      "SSRIs",
      "SNRIs",
      "TCAs"
    ]
  },
  {
    "id": "class-021",
    "system": "Nervous system",
    "systemHa": "Nervous system",
    "name": "Antiepileptics",
    "nameHa": "Magungunan farfaɗiya",
    "description": "Reduce neuronal excitability and seizure activity.",
    "descriptionHa": "Suna rage yawan tashin siginar jijiyoyi da seizures.",
    "examples": [
      "Sodium valproate",
      "Carbamazepine",
      "Lamotrigine",
      "Levetiracetam",
      "Phenytoin"
    ],
    "subgroups": [
      "Sodium-channel modulators",
      "SV2A ligands"
    ]
  },
  {
    "id": "class-022",
    "system": "Nervous system",
    "systemHa": "Nervous system",
    "name": "Antipsychotics",
    "nameHa": "Magungunan psychosis",
    "description": "Act on central neurotransmitter pathways, especially dopamine pathways.",
    "descriptionHa": "Suna shafar sinadaran sadarwa a kwakwalwa, musamman dopamine.",
    "examples": [
      "Haloperidol",
      "Risperidone",
      "Olanzapine",
      "Quetiapine",
      "Aripiprazole"
    ],
    "subgroups": [
      "First-generation",
      "Second-generation"
    ]
  },
  {
    "id": "class-023",
    "system": "Nervous system",
    "systemHa": "Nervous system",
    "name": "Anxiolytics",
    "nameHa": "Magungunan rage tashin hankali",
    "description": "Reduce anxiety through different central nervous system mechanisms.",
    "descriptionHa": "Suna rage tashin hankali ta hanyoyi daban-daban a tsarin jijiyoyi.",
    "examples": [
      "Diazepam",
      "Lorazepam",
      "Alprazolam",
      "Buspirone"
    ],
    "subgroups": [
      "Benzodiazepines",
      "Other anxiolytics"
    ]
  },
  {
    "id": "class-024",
    "system": "Endocrine",
    "systemHa": "Endocrine",
    "name": "Insulins",
    "nameHa": "Insulin",
    "description": "Replace or supplement insulin to regulate blood glucose.",
    "descriptionHa": "Suna maye gurbin ko ƙara insulin domin daidaita glucose a jini.",
    "examples": [
      "Regular insulin",
      "Insulin lispro",
      "Insulin aspart",
      "Insulin glargine",
      "NPH insulin"
    ],
    "subgroups": [
      "Rapid-acting",
      "Short-acting",
      "Intermediate-acting",
      "Long-acting"
    ]
  },
  {
    "id": "class-025",
    "system": "Endocrine",
    "systemHa": "Endocrine",
    "name": "Biguanides",
    "nameHa": "Biguanides",
    "description": "Reduce hepatic glucose production and improve insulin sensitivity.",
    "descriptionHa": "Suna rage samar da glucose a hanta tare da inganta amsar insulin.",
    "examples": [
      "Metformin"
    ],
    "subgroups": [
      "Biguanide antihyperglycaemics"
    ]
  },
  {
    "id": "class-026",
    "system": "Endocrine",
    "systemHa": "Endocrine",
    "name": "Sulfonylureas",
    "nameHa": "Sulfonylureas",
    "description": "Stimulate pancreatic beta cells to release insulin.",
    "descriptionHa": "Suna motsa beta cells na pancreas su saki insulin.",
    "examples": [
      "Gliclazide",
      "Glimepiride",
      "Glipizide",
      "Glibenclamide"
    ],
    "subgroups": [
      "Second-generation sulfonylureas"
    ]
  },
  {
    "id": "class-027",
    "system": "Endocrine",
    "systemHa": "Endocrine",
    "name": "SGLT2 inhibitors",
    "nameHa": "Masu hana SGLT2",
    "description": "Reduce renal glucose reabsorption.",
    "descriptionHa": "Suna rage sake tsotse glucose a koda.",
    "examples": [
      "Dapagliflozin",
      "Empagliflozin",
      "Canagliflozin"
    ],
    "subgroups": [
      "Gliflozins"
    ]
  },
  {
    "id": "class-028",
    "system": "Endocrine",
    "systemHa": "Endocrine",
    "name": "Thyroid hormone preparations",
    "nameHa": "Magungunan thyroid hormone",
    "description": "Replace thyroid hormone in hypothyroidism.",
    "descriptionHa": "Suna maye gurbin thyroid hormone idan ya yi ƙasa.",
    "examples": [
      "Levothyroxine",
      "Liothyronine"
    ],
    "subgroups": [
      "Synthetic T4",
      "Synthetic T3"
    ]
  },
  {
    "id": "class-029",
    "system": "Endocrine",
    "systemHa": "Endocrine",
    "name": "Antithyroid drugs",
    "nameHa": "Magungunan rage aikin thyroid",
    "description": "Reduce thyroid hormone synthesis or release.",
    "descriptionHa": "Suna rage samarwa ko sakin thyroid hormone.",
    "examples": [
      "Carbimazole",
      "Methimazole",
      "Propylthiouracil"
    ],
    "subgroups": [
      "Thionamides"
    ]
  },
  {
    "id": "class-030",
    "system": "Reproductive",
    "systemHa": "Reproductive",
    "name": "Combined hormonal contraceptives",
    "nameHa": "Magungunan hana ɗaukar ciki masu haɗin hormones",
    "description": "Contain an oestrogen and a progestogen to prevent pregnancy.",
    "descriptionHa": "Suna ƙunshe da oestrogen da progestogen domin hana ɗaukar ciki.",
    "examples": [
      "Ethinylestradiol + levonorgestrel",
      "Ethinylestradiol + drospirenone"
    ],
    "subgroups": [
      "Combined oral contraceptives",
      "Patch",
      "Vaginal ring"
    ]
  },
  {
    "id": "class-031",
    "system": "Reproductive",
    "systemHa": "Reproductive",
    "name": "Progestogens",
    "nameHa": "Progestogens",
    "description": "Progesterone-like medicines used in reproductive health.",
    "descriptionHa": "Magunguna masu kama da progesterone da ake amfani da su a lafiyar haihuwa.",
    "examples": [
      "Medroxyprogesterone acetate",
      "Norethisterone",
      "Levonorgestrel",
      "Micronised progesterone"
    ],
    "subgroups": [
      "Progestins",
      "Progesterone"
    ]
  },
  {
    "id": "class-032",
    "system": "Reproductive",
    "systemHa": "Reproductive",
    "name": "Fertility medicines",
    "nameHa": "Magungunan taimakon haihuwa",
    "description": "Affect ovulation or reproductive hormone pathways.",
    "descriptionHa": "Suna shafar ovulation ko hormones na haihuwa.",
    "examples": [
      "Clomifene",
      "Letrozole",
      "Menotropins",
      "Follitropin alfa"
    ],
    "subgroups": [
      "Ovulation induction",
      "Gonadotropins"
    ]
  },
  {
    "id": "class-033",
    "system": "Reproductive",
    "systemHa": "Reproductive",
    "name": "Uterotonics",
    "nameHa": "Magungunan ƙarfafa matsewar mahaifa",
    "description": "Stimulate uterine contractions in specific obstetric settings.",
    "descriptionHa": "Suna ƙarfafa matsewar mahaifa a wasu yanayin haihuwa.",
    "examples": [
      "Oxytocin",
      "Misoprostol",
      "Ergometrine",
      "Carboprost"
    ],
    "subgroups": [
      "Oxytocics",
      "Prostaglandins"
    ]
  },
  {
    "id": "class-034",
    "system": "Musculoskeletal",
    "systemHa": "Musculoskeletal",
    "name": "NSAIDs",
    "nameHa": "Magungunan rage kumburi da zafi",
    "description": "Reduce pain, inflammation and fever by inhibiting cyclo-oxygenase enzymes.",
    "descriptionHa": "Suna rage zafi, kumburi da zazzabi ta hanyar hana COX enzymes.",
    "examples": [
      "Ibuprofen",
      "Diclofenac",
      "Naproxen",
      "Celecoxib",
      "Indomethacin"
    ],
    "subgroups": [
      "Non-selective COX inhibitors",
      "COX-2 selective"
    ]
  },
  {
    "id": "class-035",
    "system": "Musculoskeletal",
    "systemHa": "Musculoskeletal",
    "name": "DMARDs",
    "nameHa": "Magungunan gyara cututtukan rheumatic",
    "description": "Modify inflammatory disease activity and may slow joint damage.",
    "descriptionHa": "Suna rage ayyukan kumburi kuma na iya rage lalacewar gaɓoɓi.",
    "examples": [
      "Methotrexate",
      "Hydroxychloroquine",
      "Sulfasalazine",
      "Leflunomide"
    ],
    "subgroups": [
      "Conventional synthetic",
      "Biologic"
    ]
  },
  {
    "id": "class-036",
    "system": "Musculoskeletal",
    "systemHa": "Musculoskeletal",
    "name": "Antigout medicines",
    "nameHa": "Magungunan gout",
    "description": "Treat gout flares or reduce urate levels over time.",
    "descriptionHa": "Ana amfani da su wajen kula da gout ko rage urate.",
    "examples": [
      "Allopurinol",
      "Febuxostat",
      "Colchicine",
      "Probenecid"
    ],
    "subgroups": [
      "Xanthine oxidase inhibitors",
      "Uricosurics"
    ]
  },
  {
    "id": "class-037",
    "system": "Anti-infectives",
    "systemHa": "Anti-infectives",
    "name": "Penicillins",
    "nameHa": "Penicillins",
    "description": "Beta-lactam antibiotics that inhibit bacterial cell-wall synthesis.",
    "descriptionHa": "Antibiotics ne na beta-lactam da ke hana gina bangon kwayoyin bacteria.",
    "examples": [
      "Benzylpenicillin",
      "Amoxicillin",
      "Flucloxacillin",
      "Piperacillin + tazobactam"
    ],
    "subgroups": [
      "Natural penicillins",
      "Aminopenicillins",
      "Antipseudomonal"
    ]
  },
  {
    "id": "class-038",
    "system": "Anti-infectives",
    "systemHa": "Anti-infectives",
    "name": "Cephalosporins",
    "nameHa": "Cephalosporins",
    "description": "Beta-lactam antibiotics grouped into generations.",
    "descriptionHa": "Antibiotics na beta-lactam da aka rarraba zuwa generations.",
    "examples": [
      "Cefalexin",
      "Cefuroxime",
      "Ceftriaxone",
      "Cefixime",
      "Cefepime"
    ],
    "subgroups": [
      "First generation",
      "Second generation",
      "Third generation",
      "Fourth generation"
    ]
  },
  {
    "id": "class-039",
    "system": "Anti-infectives",
    "systemHa": "Anti-infectives",
    "name": "Macrolides",
    "nameHa": "Macrolides",
    "description": "Inhibit bacterial protein synthesis at the 50S ribosome.",
    "descriptionHa": "Suna hana bacteria samar da protein a 50S ribosome.",
    "examples": [
      "Azithromycin",
      "Clarithromycin",
      "Erythromycin"
    ],
    "subgroups": [
      "Macrolide antibiotics"
    ]
  },
  {
    "id": "class-040",
    "system": "Anti-infectives",
    "systemHa": "Anti-infectives",
    "name": "Tetracyclines",
    "nameHa": "Tetracyclines",
    "description": "Inhibit bacterial protein synthesis at the 30S ribosome.",
    "descriptionHa": "Suna hana samar da protein a 30S ribosome.",
    "examples": [
      "Doxycycline",
      "Tetracycline",
      "Minocycline"
    ],
    "subgroups": [
      "Tetracycline antibiotics"
    ]
  },
  {
    "id": "class-041",
    "system": "Anti-infectives",
    "systemHa": "Anti-infectives",
    "name": "Fluoroquinolones",
    "nameHa": "Fluoroquinolones",
    "description": "Inhibit bacterial DNA gyrase and topoisomerase IV.",
    "descriptionHa": "Suna hana wasu enzymes da bacteria ke amfani da su wajen DNA.",
    "examples": [
      "Ciprofloxacin",
      "Levofloxacin",
      "Moxifloxacin",
      "Ofloxacin"
    ],
    "subgroups": [
      "Fluoroquinolone antibiotics"
    ]
  },
  {
    "id": "class-042",
    "system": "Anti-infectives",
    "systemHa": "Anti-infectives",
    "name": "Antifungals",
    "nameHa": "Magungunan fungal",
    "description": "Treat fungal infections through different fungal targets.",
    "descriptionHa": "Suna magance fungal infections ta hanyoyi daban-daban.",
    "examples": [
      "Fluconazole",
      "Itraconazole",
      "Terbinafine",
      "Nystatin",
      "Amphotericin B"
    ],
    "subgroups": [
      "Azoles",
      "Allylamines",
      "Polyenes",
      "Echinocandins"
    ]
  },
  {
    "id": "class-043",
    "system": "Anti-infectives",
    "systemHa": "Anti-infectives",
    "name": "Antivirals",
    "nameHa": "Magungunan virus",
    "description": "Inhibit viral replication or other stages of the viral life cycle.",
    "descriptionHa": "Suna hana yawaitar virus ko wasu matakan rayuwarsa.",
    "examples": [
      "Aciclovir",
      "Valaciclovir",
      "Oseltamivir",
      "Tenofovir",
      "Dolutegravir"
    ],
    "subgroups": [
      "Anti-herpes",
      "Anti-influenza",
      "Antiretrovirals"
    ]
  },
  {
    "id": "class-044",
    "system": "Anti-infectives",
    "systemHa": "Anti-infectives",
    "name": "Antimalarials",
    "nameHa": "Magungunan zazzabin cizon sauro",
    "description": "Used in malaria prevention or treatment according to species and resistance patterns.",
    "descriptionHa": "Ana amfani da su wajen kariya ko maganin malaria bisa nau'in parasite da resistance.",
    "examples": [
      "Artemether + lumefantrine",
      "Artesunate",
      "Quinine",
      "Chloroquine",
      "Sulfadoxine + pyrimethamine"
    ],
    "subgroups": [
      "Artemisinin-based combinations",
      "Quinolines"
    ]
  },
  {
    "id": "class-045",
    "system": "Hematology",
    "systemHa": "Hematology",
    "name": "Anticoagulants",
    "nameHa": "Masu hana daskarewar jini",
    "description": "Reduce blood coagulation by targeting clotting pathways.",
    "descriptionHa": "Suna rage daskarewar jini ta hanyar shafar clotting pathways.",
    "examples": [
      "Warfarin",
      "Heparin",
      "Enoxaparin",
      "Apixaban",
      "Rivaroxaban"
    ],
    "subgroups": [
      "Vitamin K antagonists",
      "Heparins",
      "DOACs"
    ]
  },
  {
    "id": "class-046",
    "system": "Hematology",
    "systemHa": "Hematology",
    "name": "Antiplatelet agents",
    "nameHa": "Masu hana haɗuwar platelets",
    "description": "Reduce platelet activation or aggregation.",
    "descriptionHa": "Suna rage kunnawa ko haɗuwar platelets.",
    "examples": [
      "Aspirin",
      "Clopidogrel",
      "Ticagrelor",
      "Prasugrel"
    ],
    "subgroups": [
      "COX inhibitors",
      "P2Y12 inhibitors"
    ]
  },
  {
    "id": "class-047",
    "system": "Hematology",
    "systemHa": "Hematology",
    "name": "Haematinics",
    "nameHa": "Magungunan samar da jini",
    "description": "Support haemoglobin production and correct selected deficiencies.",
    "descriptionHa": "Suna taimakawa samar da haemoglobin da gyara wasu ƙarancin sinadarai.",
    "examples": [
      "Ferrous sulfate",
      "Ferrous fumarate",
      "Folic acid",
      "Hydroxocobalamin"
    ],
    "subgroups": [
      "Iron preparations",
      "Folate",
      "Vitamin B12"
    ]
  },
  {
    "id": "class-048",
    "system": "Dermatology",
    "systemHa": "Dermatology",
    "name": "Topical corticosteroids",
    "nameHa": "Corticosteroids na shafawa",
    "description": "Reduce local skin inflammation and immune activity.",
    "descriptionHa": "Suna rage kumburi da aikin garkuwar jiki a fata.",
    "examples": [
      "Hydrocortisone",
      "Betamethasone",
      "Clobetasol",
      "Mometasone"
    ],
    "subgroups": [
      "Mild",
      "Moderate",
      "Potent",
      "Very potent"
    ]
  },
  {
    "id": "class-049",
    "system": "Dermatology",
    "systemHa": "Dermatology",
    "name": "Topical antifungals",
    "nameHa": "Magungunan fungal na shafawa",
    "description": "Treat superficial fungal infections of the skin.",
    "descriptionHa": "Suna magance fungal infection na saman fata.",
    "examples": [
      "Clotrimazole",
      "Miconazole",
      "Ketoconazole",
      "Terbinafine"
    ],
    "subgroups": [
      "Azoles",
      "Allylamines"
    ]
  },
  {
    "id": "class-050",
    "system": "Dermatology",
    "systemHa": "Dermatology",
    "name": "Anti-acne preparations",
    "nameHa": "Magungunan kurajen fuska",
    "description": "Target comedones, inflammation or bacterial contribution in acne.",
    "descriptionHa": "Suna aiki kan toshewar pores, kumburi ko bacteria masu alaƙa da acne.",
    "examples": [
      "Benzoyl peroxide",
      "Adapalene",
      "Tretinoin",
      "Azelaic acid"
    ],
    "subgroups": [
      "Retinoids",
      "Antimicrobials",
      "Keratolytics"
    ]
  },
  {
    "id": "class-051",
    "system": "Ophthalmology & ENT",
    "systemHa": "Ophthalmology & ENT",
    "name": "Antiglaucoma drugs",
    "nameHa": "Magungunan glaucoma",
    "description": "Lower intraocular pressure by reducing aqueous production or increasing outflow.",
    "descriptionHa": "Suna rage matsin ido ta rage samar da aqueous ko ƙara fitar da shi.",
    "examples": [
      "Latanoprost",
      "Timolol",
      "Brimonidine",
      "Dorzolamide"
    ],
    "subgroups": [
      "Prostaglandin analogues",
      "Beta blockers",
      "Alpha-2 agonists"
    ]
  },
  {
    "id": "class-052",
    "system": "Ophthalmology & ENT",
    "systemHa": "Ophthalmology & ENT",
    "name": "Nasal decongestants",
    "nameHa": "Magungunan buɗe hanci",
    "description": "Reduce nasal mucosal congestion through vasoconstriction.",
    "descriptionHa": "Suna rage toshewar hanci ta matse jijiyoyin jini.",
    "examples": [
      "Xylometazoline",
      "Oxymetazoline",
      "Phenylephrine"
    ],
    "subgroups": [
      "Topical sympathomimetics"
    ]
  },
  {
    "id": "class-053",
    "system": "Ophthalmology & ENT",
    "systemHa": "Ophthalmology & ENT",
    "name": "Ophthalmic antibiotics",
    "nameHa": "Antibiotics na ido",
    "description": "Antibiotic preparations formulated for selected eye infections.",
    "descriptionHa": "Antibiotics ne da aka tsara don wasu infections na ido.",
    "examples": [
      "Chloramphenicol",
      "Ofloxacin",
      "Tobramycin",
      "Moxifloxacin"
    ],
    "subgroups": [
      "Topical ocular antibacterials"
    ]
  },
  {
    "id": "class-054",
    "system": "Renal & Urology",
    "systemHa": "Renal & Urology",
    "name": "Urinary antispasmodics",
    "nameHa": "Magungunan rage tsukewar mafitsara",
    "description": "Reduce bladder spasms or urgency in selected conditions.",
    "descriptionHa": "Suna rage tsukewar mafitsara ko yawan jin buƙatar fitsari.",
    "examples": [
      "Oxybutynin",
      "Tolterodine",
      "Solifenacin",
      "Mirabegron"
    ],
    "subgroups": [
      "Antimuscarinics",
      "Beta-3 agonists"
    ]
  },
  {
    "id": "class-055",
    "system": "Renal & Urology",
    "systemHa": "Renal & Urology",
    "name": "Alpha-1 blockers",
    "nameHa": "Masu hana alpha-1 receptor",
    "description": "Relax smooth muscle in the prostate and bladder neck.",
    "descriptionHa": "Suna sassauta tsokoki a prostate da bakin mafitsara.",
    "examples": [
      "Tamsulosin",
      "Alfuzosin",
      "Doxazosin",
      "Terazosin"
    ],
    "subgroups": [
      "Uroselective",
      "Non-uroselective"
    ]
  },
  {
    "id": "class-056",
    "system": "Immunology & Oncology",
    "systemHa": "Immunology & Oncology",
    "name": "Immunosuppressants",
    "nameHa": "Magungunan rage aikin garkuwar jiki",
    "description": "Reduce immune system activity in selected conditions.",
    "descriptionHa": "Suna rage aikin garkuwar jiki a wasu cututtuka.",
    "examples": [
      "Azathioprine",
      "Ciclosporin",
      "Tacrolimus",
      "Mycophenolate mofetil"
    ],
    "subgroups": [
      "Calcineurin inhibitors",
      "Antimetabolites"
    ]
  },
  {
    "id": "class-057",
    "system": "Immunology & Oncology",
    "systemHa": "Immunology & Oncology",
    "name": "Cytotoxic antineoplastics",
    "nameHa": "Magungunan chemotherapy",
    "description": "Interfere with cell division or DNA processes in cancer treatment.",
    "descriptionHa": "Suna shafar rabuwar ƙwayoyin halitta ko DNA wajen maganin kansa.",
    "examples": [
      "Cyclophosphamide",
      "Methotrexate",
      "Doxorubicin",
      "Cisplatin",
      "Fluorouracil"
    ],
    "subgroups": [
      "Alkylating agents",
      "Antimetabolites",
      "Anthracyclines",
      "Platinum compounds"
    ]
  }
];
