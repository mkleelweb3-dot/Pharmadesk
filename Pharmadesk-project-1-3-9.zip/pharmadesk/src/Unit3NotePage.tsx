import { unit3Notes } from './unit3Notes';
import { BookOpen, ShieldAlert } from 'lucide-react';

const terminology = /\b( dopamine|dopamine|norepinephrine|serotonin|GABA-A|NMDA|D2|5-HT2A|5-HT1A|alpha-2|α4β2|acetylcholinesterase|MAO-B|COMT|SV2A|voltage-gated sodium channels|nicotinic receptors|muscarinic receptors|opioid receptors|adenosine receptors|reuptake inhibition|partial agonist|antagonist|agonist|receptor|neurotransmitter|CYP1A2|CYP3A4|QT prolongation|serotonin syndrome|respiratory depression|extrapyramidal symptoms|tardive dyskinesia|malignant hyperthermia|cholinergic|catecholamine signalling)\b/gi;
function colorTerms(text:string){
  const parts=text.split(terminology);
  return parts.map((part,i)=> terminology.test(part) ? <span key={i} className="unit3-term">{part}</span> : part);
}
export function Unit3NotePage({number,onBack}:{number:number;onBack:()=>void}) {
  const note=unit3Notes[number];
  if(!note) return null;
  return <section className="chapter-detail unit-note-page">
    <button className="back" onClick={onBack}>← Back to units</button>
    <div className="unit-note-kicker">UNIT III · DRUGS AFFECTING THE CENTRAL NERVOUS SYSTEM</div>
    <div className="unit-note-heading"><span>CLASS {note.number}</span><h1>{note.title}</h1><p>{note.overview}</p></div>
    <div className="unit3-color-legend"><span className="unit3-key">Key points</span><span className="unit3-generic">Drug/class terms</span><span className="unit3-brand">Examples/brand references</span></div>
    {note.sections.map((section,index)=><section className="unit-note-section" key={section.title}>
      <h2><span>{index+1}</span>{section.title}</h2>
      <ul>{section.points.map((point,i)=><li key={i}>{colorTerms(point)}</li>)}</ul>
    </section>)}
    <div className="unit-note-warning"><ShieldAlert size={17}/><p><b>Educational reference only.</b> These concise notes support study and do not replace current prescribing information, clinical guidelines or professional judgement. Confirm drug-specific contraindications, doses and interactions from trusted references.</p></div>
    <div className="unit-note-footer"><BookOpen size={15}/> Pharmadesk · Unit III · Class {note.number}</div>
  </section>;
}
