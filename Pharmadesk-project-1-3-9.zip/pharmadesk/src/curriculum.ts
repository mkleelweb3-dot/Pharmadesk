export type CurriculumChapter = { number: number; title: string };
export type CurriculumUnit = { id: string; title: string; chapters: CurriculumChapter[] };

// Curriculum structure transcribed from the user's supplied contents pages.
// Drug examples and author/contributor names are intentionally not included.
export const curriculumUnits: CurriculumUnit[] = [
  { id: 'unit-1', title: 'Principles of Drug Therapy', chapters: [
    { number: 1, title: 'Pharmacokinetics' },
    { number: 2, title: 'Drug–Receptor Interactions and Pharmacodynamics' },
  ]},
  { id: 'unit-2', title: 'Drugs Affecting the Autonomic Nervous System', chapters: [
    { number: 3, title: 'The Autonomic Nervous System' },
    { number: 4, title: 'Cholinergic Agonists' },
    { number: 5, title: 'Cholinergic Antagonists' },
    { number: 6, title: 'Adrenergic Agonists' },
    { number: 7, title: 'Adrenergic Antagonists' },
  ]},
  { id: 'unit-3', title: 'Drugs Affecting the Central Nervous System', chapters: [
    { number: 8, title: 'Drugs for Neurodegenerative Diseases' },
    { number: 9, title: 'Anxiolytic and Hypnotic Drugs' },
    { number: 10, title: 'Antidepressants' },
    { number: 11, title: 'Antipsychotic Drugs' },
    { number: 12, title: 'Drugs for Epilepsy' },
    { number: 13, title: 'Anesthetics' },
    { number: 14, title: 'Opioids' },
    { number: 15, title: 'Drugs of Abuse' },
    { number: 16, title: 'CNS Stimulants' },
  ]},
  { id: 'unit-4', title: 'Drugs Affecting the Cardiovascular System', chapters: [
    { number: 17, title: 'Antihypertensives' },
    { number: 18, title: 'Diuretics' },
    { number: 19, title: 'Heart Failure' },
    { number: 20, title: 'Antiarrhythmics' },
    { number: 21, title: 'Antianginal Drugs' },
    { number: 22, title: 'Anticoagulants and Antiplatelet Agents' },
    { number: 23, title: 'Drugs for Hyperlipidemia' },
  ]},
  { id: 'unit-5', title: 'Drugs Affecting the Endocrine System', chapters: [
    { number: 24, title: 'Pituitary and Thyroid' },
    { number: 25, title: 'Drugs for Diabetes' },
    { number: 26, title: 'Estrogens and Androgens' },
    { number: 27, title: 'Adrenal Hormones' },
    { number: 28, title: 'Drugs for Obesity' },
  ]},
  { id: 'unit-6', title: 'Drugs for Other Disorders', chapters: [
    { number: 29, title: 'Drugs for Disorders of the Respiratory System' },
    { number: 30, title: 'Antihistamines' },
    { number: 31, title: 'Gastrointestinal and Antiemetic Drugs' },
    { number: 32, title: 'Drugs for Urologic Disorders' },
    { number: 33, title: 'Drugs for Anemia' },
    { number: 34, title: 'Drugs for Dermatologic Disorders' },
    { number: 35, title: 'Drugs for Bone Disorders' },
    { number: 36, title: 'Anti-inflammatory, Antipyretic, and Analgesic Agents' },
  ]},
  { id: 'unit-7', title: 'Chemotherapeutic Drugs', chapters: [
    { number: 37, title: 'Principles of Antimicrobial Therapy' },
    { number: 38, title: 'Cell Wall Inhibitors' },
    { number: 39, title: 'Protein Synthesis Inhibitors' },
    { number: 40, title: 'Quinolones, Folic Acid Antagonists, and Urinary Tract Antiseptics' },
    { number: 41, title: 'Antimycobacterial Drugs' },
    { number: 42, title: 'Antifungal Drugs' },
    { number: 43, title: 'Antiprotozoal Drugs' },
    { number: 44, title: 'Anthelmintic Drugs' },
    { number: 45, title: 'Antiviral Drugs' },
    { number: 46, title: 'Anticancer Drugs' },
    { number: 47, title: 'Immunosuppressants' },
  ]},
  { id: 'unit-8', title: 'Toxicology', chapters: [
    { number: 48, title: 'Clinical Toxicology' },
  ]},
];
