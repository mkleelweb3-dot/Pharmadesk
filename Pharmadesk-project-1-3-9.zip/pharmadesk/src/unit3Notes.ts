export type Unit3Section={title:string; points:string[]};
export type Unit3Note={number:number;title:string;overview:string;sections:Unit3Section[]};
export const unit3Notes:Record<number,Unit3Note>={
8:{number:8,title:'Drugs for Neurodegenerative Diseases',overview:'Agents used to manage symptoms or modify selected neurodegenerative diseases; treatment is usually individualized.',sections:[
{title:'1. Indication',points:[
'Parkinson disease symptoms; Alzheimer disease symptoms; selected multiple sclerosis (MS) manifestations or disease-modifying treatment; amyotrophic lateral sclerosis (ALS) in selected patients.',
]},
{title:'2. Groups and examples of drugs',points:[
'Anti-Parkinson: levodopa/carbidopa; dopamine agonists (pramipexole, ropinirole, rotigotine); MAO-B inhibitors (rasagiline, selegiline); COMT inhibitors (entacapone, tolcapone); antimuscarinics (benztropine, trihexyphenidyl); amantadine.',
'Anti-Alzheimer: acetylcholinesterase inhibitors (donepezil, galantamine, rivastigmine); NMDA receptor antagonist (memantine).',
'MS: interferon beta, glatiramer acetate, dimethyl fumarate, fingolimod, teriflunomide, natalizumab, selected immunosuppressants/corticosteroids; dalfampridine for selected symptomatic walking impairment.',
'ALS: riluzole.',
]},
{title:'3. Mechanism of action',points:[
'Levodopa is converted to dopamine in the CNS; carbidopa inhibits peripheral aromatic L-amino-acid decarboxylase.',
'Dopamine agonists stimulate dopamine receptors; MAO-B inhibitors reduce dopamine breakdown; COMT inhibitors reduce levodopa/dopamine metabolism.',
'Antimuscarinics reduce central cholinergic activity; amantadine has dopaminergic and NMDA-related actions.',
'Alzheimer cholinesterase inhibitors increase acetylcholine availability; memantine modulates NMDA receptor activity.',
'MS disease-modifying drugs alter immune activity; dalfampridine blocks potassium channels and may improve conduction in demyelinated axons.',
'Riluzole reduces glutamatergic excitotoxic signalling through several actions.',
]},
{title:'4. Uses',points:[
'Parkinsonism: symptom control, especially motor symptoms.',
'Alzheimer disease: symptomatic cognitive treatment.',
'MS: relapse management and/or reduction of disease activity, depending on agent; dalfampridine is symptomatic.',
'ALS: riluzole may modestly slow disease progression in eligible patients.',
]},
{title:'5. Side effects and adverse effects',points:[
'Parkinson medicines: nausea, orthostatic hypotension, dyskinesias, hallucinations, sleepiness, impulse-control symptoms; antimuscarinics may cause dry mouth, constipation, blurred vision and confusion.',
'Alzheimer medicines: nausea, diarrhoea, bradycardia, syncope; memantine may cause dizziness or confusion.',
'MS therapies: infection risk, infusion/injection reactions, hepatic or hematologic effects and other agent-specific risks; some agents have serious immune-related risks.',
'Riluzole: nausea, fatigue and potential hepatic injury.',
]},
{title:'6. Contraindications and cautions',points:[
'Contraindications are agent-specific. Review cardiac conduction/bradycardia risks for cholinesterase inhibitors; hepatic disease and monitoring for selected drugs; infection and vaccination considerations for immunomodulating MS treatments; pregnancy-related restrictions for selected MS drugs.',
'Assess psychosis, severe hypotension, glaucoma, urinary retention and cognitive vulnerability where relevant to Parkinson medicines.',
]},
{title:'7. Drug interactions',points:[
'Levodopa may interact with nonselective MAO inhibitors and iron products; dopamine antagonists may reduce benefit.',
'Dopamine agonists may add to hypotension or sedation.',
'Antimuscarinic medicines can oppose cholinesterase inhibitors and add cognitive/constipation effects.',
'MS drugs have agent-specific interactions, including immunosuppressive combinations and metabolism-related interactions.',
'Riluzole exposure can be affected by CYP1A2 inhibitors or inducers; avoid or monitor combinations according to product guidance.',
]},
]},
9:{number:9,title:'Anxiolytic and Hypnotic Drugs',overview:'Medicines used to reduce anxiety or facilitate sleep; selection depends on diagnosis, duration, risk and patient factors.',sections:[
{title:'1. Indication',points:[
'Anxiety disorders, acute anxiety in selected situations, insomnia and selected procedural sedation or seizure-related uses, depending on agent.',
]},
{title:'2. Groups and examples of drugs',points:[
'Benzodiazepines: alprazolam, chlordiazepoxide, clonazepam, clorazepate, diazepam, estazolam, flurazepam, lorazepam, midazolam, oxazepam, quazepam, temazepam, triazolam.',
'Benzodiazepine antagonist: flumazenil.',
'Other anxiolytics: buspirone; antidepressants used for anxiety (selected SSRIs/SNRIs).',
'Barbiturates: amobarbital, pentobarbital, phenobarbital, secobarbital, thiopental.',
'Other hypnotics: doxepin, eszopiclone, ramelteon, zaleplon, zolpidem; selected antihistamines.',
]},
{title:'3. Mechanism of action',points:[
'Benzodiazepines enhance GABA-A receptor-mediated inhibitory signalling by increasing the frequency of chloride-channel opening in the presence of GABA.',
'Buspirone acts mainly as a partial agonist at 5-HT1A receptors.',
'Barbiturates enhance GABA-A signalling, typically increasing duration of channel opening; at higher concentrations they may have additional actions.',
'Z-drugs modulate GABA-A receptors; ramelteon acts at melatonin MT1/MT2 receptors; doxepin at low doses primarily blocks histamine H1 receptors.',
]},
{title:'4. Uses',points:[
'Benzodiazepines: selected anxiety, seizures, acute agitation, procedural sedation, muscle spasm and withdrawal management.',
'Buspirone: generalized anxiety disorder.',
'Barbiturates: selected seizure, anesthesia or other specific indications.',
'Z-drugs, ramelteon and low-dose doxepin: selected insomnia presentations.',
]},
{title:'5. Side effects and adverse effects',points:[
'Sedation, dizziness, impaired coordination, memory impairment, falls, tolerance and dependence.',
'Respiratory depression and profound sedation, especially with opioids or alcohol.',
'Paradoxical agitation may occur; barbiturates have a narrow therapeutic margin.',
'Z-drugs may cause complex sleep behaviours; flumazenil may precipitate seizures in susceptible patients.',
]},
{title:'6. Contraindications and cautions',points:[
'Avoid or use extreme caution in severe respiratory insufficiency, sleep apnea, acute intoxication with CNS depressants, pregnancy-related situations and patients at risk of falls or dependence, as applicable.',
'Flumazenil can be hazardous in chronic benzodiazepine users, mixed overdoses or seizure-prone patients.',
'Drug-specific contraindications vary; consult prescribing information.',
]},
{title:'7. Drug interactions',points:[
'Opioids, alcohol and other CNS depressants increase sedation and respiratory depression.',
'CYP3A4 inhibitors or inducers can alter concentrations of certain benzodiazepines and hypnotics.',
'Barbiturates induce hepatic enzymes and can lower concentrations of many medicines.',
'Buspirone levels may change with CYP3A4 inhibitors/inducers.',
]},
]},
10:{number:10,title:'Antidepressants',overview:'Drug classes used in depressive disorders and several other psychiatric, pain and related conditions.',sections:[
{title:'1. Indication',points:[
'Major depressive disorder and selected anxiety, obsessive-compulsive, neuropathic pain, migraine, sleep and other conditions depending on drug.',
]},
{title:'2. Groups and examples of drugs',points:[
'SSRIs: citalopram, escitalopram, fluoxetine, fluvoxamine, paroxetine, sertraline.',
'SNRIs: desvenlafaxine, duloxetine, levomilnacipran, venlafaxine.',
'Atypical antidepressants: bupropion, mirtazapine, nefazodone, trazodone, vilazodone, vortioxetine.',
'TCAs: amitriptyline, amoxapine, clomipramine, desipramine, doxepin, imipramine, maprotiline, nortriptyline, protriptyline, trimipramine.',
'MAOIs: isocarboxazid, phenelzine, selegiline, tranylcypromine.',
]},
{title:'3. Mechanism of action',points:[
'SSRIs inhibit serotonin reuptake; SNRIs inhibit serotonin and norepinephrine reuptake.',
'TCAs inhibit serotonin and norepinephrine reuptake and also block several receptors.',
'MAOIs inhibit monoamine oxidase, increasing monoamine availability.',
'Bupropion inhibits norepinephrine/dopamine reuptake; mirtazapine antagonizes alpha-2 and selected serotonin receptors; trazodone and vilazodone/vortioxetine have multimodal serotonergic actions.',
]},
{title:'4. Uses',points:[
'Depression; selected anxiety and OCD-related disorders; neuropathic pain (selected SNRIs/TCAs); smoking cessation (bupropion); insomnia (selected agents); other agent-specific indications.',
]},
{title:'5. Side effects and adverse effects',points:[
'SSRIs/SNRIs: nausea, sexual dysfunction, sleep disturbance, hyponatremia, bleeding risk and serotonin syndrome.',
'TCAs: anticholinergic effects, orthostatic hypotension, sedation and cardiac toxicity in overdose.',
'MAOIs: orthostatic hypotension, weight gain, interactions and hypertensive reactions with tyramine or interacting drugs.',
'Bupropion: insomnia, agitation and dose-related seizure risk; mirtazapine: sedation and weight gain; trazodone: sedation and rare priapism.',
]},
{title:'6. Contraindications and cautions',points:[
'MAOIs have important contraindications involving serotonergic drugs and certain sympathomimetics; washout intervals are required.',
'Use caution with bipolar disorder, seizure risk, cardiac disease, bleeding risk, hyponatremia, pregnancy and suicidality monitoring as applicable.',
'Drug-specific contraindications and monitoring apply.',
]},
{title:'7. Drug interactions',points:[
'Serotonergic combinations may cause serotonin syndrome.',
'MAOIs interact with serotonergic agents, sympathomimetics and tyramine-rich foods; follow washout guidance.',
'SSRIs can inhibit CYP enzymes and alter concentrations of other medicines.',
'Anticoagulants/antiplatelets and NSAIDs may increase bleeding risk with serotonergic antidepressants.',
'TCAs may interact with anticholinergics, sedatives and medicines affecting cardiac conduction.',
]},
]},
11:{number:11,title:'Antipsychotic Drugs',overview:'Medicines used to treat psychotic symptoms and selected mood, behavioural and other conditions.',sections:[
{title:'1. Indication',points:[
'Schizophrenia and other psychotic disorders; selected acute mania, bipolar disorder, severe agitation and other indications depending on agent.',
]},
{title:'2. Groups and examples of drugs',points:[
'First-generation, low potency: chlorpromazine, thioridazine.',
'First-generation, higher potency/other: fluphenazine, haloperidol, loxapine, perphenazine, pimozide, prochlorperazine, thiothixene, trifluoperazine.',
'Second-generation: aripiprazole, asenapine, clozapine, iloperidone, lurasidone, olanzapine, paliperidone, quetiapine, risperidone, ziprasidone.',
]},
{title:'3. Mechanism of action',points:[
'Most antipsychotics reduce dopamine D2 receptor signalling; second-generation agents also antagonize 5-HT2A receptors to varying degrees.',
'Aripiprazole and related agents act as partial agonists at D2 and selected serotonin receptors.',
'Clozapine has a broad receptor profile and distinct efficacy/safety considerations.',
]},
{title:'4. Uses',points:[
'Psychotic disorders; acute mania and bipolar maintenance (selected drugs); adjunctive treatment of depression (selected drugs); agitation or nausea for selected agents; clozapine for treatment-resistant schizophrenia and selected suicide-risk reduction.',
]},
{title:'5. Side effects and adverse effects',points:[
'Extrapyramidal symptoms (acute dystonia, akathisia, parkinsonism), tardive dyskinesia and hyperprolactinemia.',
'Sedation, orthostatic hypotension and anticholinergic effects.',
'Metabolic effects: weight gain, dyslipidemia and hyperglycemia.',
'QT prolongation; neuroleptic malignant syndrome.',
'Clozapine: severe neutropenia/agranulocytosis risk, myocarditis, seizures and constipation/ileus.',
]},
{title:'6. Contraindications and cautions',points:[
'Cautions include QT-risk, metabolic disease, Parkinsonism, dementia-related psychosis in older adults, seizure risk and hypotension.',
'Clozapine requires mandated blood monitoring and careful assessment of bowel, cardiac and other risks.',
'Contraindications differ by agent; check current prescribing information.',
]},
{title:'7. Drug interactions',points:[
'Other CNS depressants increase sedation.',
'QT-prolonging medicines may add cardiac risk.',
'CYP inhibitors/inducers can alter antipsychotic exposure.',
'Anticholinergic combinations increase constipation, urinary retention and cognitive effects.',
'Dopamine agonists may oppose antipsychotic effects.',
]},
]},
12:{number:12,title:'Drugs for Epilepsy',overview:'Antiseizure medicines reduce seizure occurrence through diverse neuronal mechanisms.',sections:[
{title:'1. Indication',points:[
'Treatment or prevention of seizure types and epilepsy syndromes; selected agents also treat neuropathic pain, mood disorders or migraine.',
]},
{title:'2. Groups and examples of drugs',points:[
'Older/established: carbamazepine, diazepam, divalproex/valproate, ethosuximide, lorazepam, phenobarbital, phenytoin, primidone.',
'Newer/other: clobazam, eslicarbazepine, ezogabine (retigabine), felbamate, fosphenytoin, gabapentin, lacosamide, lamotrigine, levetiracetam, oxcarbazepine, perampanel, pregabalin, rufinamide, tiagabine, topiramate, vigabatrin, zonisamide.',
]},
{title:'3. Mechanism of action',points:[
'Mechanisms include voltage-gated sodium-channel modulation, calcium-channel effects, enhancement of GABA signalling, reduction of glutamatergic signalling and SV2A binding.',
'Ethosuximide primarily reduces thalamic T-type calcium currents.',
'Levetiracetam binds SV2A; gabapentin/pregabalin bind alpha-2-delta calcium-channel subunits.',
]},
{title:'4. Uses',points:[
'Drug selection depends on seizure type and syndrome; examples include ethosuximide for absence seizures and selected medicines for focal or generalized seizures.',
'Some agents are used for neuropathic pain, migraine prevention or mood disorders.',
]},
{title:'5. Side effects and adverse effects',points:[
'Dizziness, somnolence, diplopia, ataxia, fatigue and cognitive effects.',
'Serious risks include rash/SJS-TEN, hepatotoxicity, hematologic effects, teratogenicity, mood changes/suicidality and drug-specific toxicities.',
'Valproate: hepatic, pancreatic, hematologic and reproductive risks; phenytoin: gingival hyperplasia, ataxia and rash; vigabatrin: visual-field toxicity.',
]},
{title:'6. Contraindications and cautions',points:[
'Contraindications are agent-specific; pregnancy and reproductive planning are important, particularly with valproate and selected agents.',
'Consider hepatic/renal impairment, conduction disease, rash history, mood changes and enzyme-induction potential.',
'Do not abruptly discontinue many antiseizure medicines.',
]},
{title:'7. Drug interactions',points:[
'Enzyme-inducing drugs (e.g., carbamazepine, phenytoin, phenobarbital) may lower concentrations of many medicines.',
'Valproate can increase concentrations of selected drugs and affect protein binding/metabolism.',
'Hormonal contraceptive efficacy may be reduced by selected enzyme-inducing agents.',
'Sedatives and alcohol may increase CNS depression.',
]},
]},
13:{number:13,title:'Anesthetics',overview:'Agents that produce general or local anesthesia, analgesia, sedation or neuromuscular blockade in monitored clinical settings.',sections:[
{title:'1. Indication',points:[
'General anesthesia, regional/local anesthesia, procedural sedation, pain management and facilitation of intubation or surgery.',
]},
{title:'2. Groups and examples of drugs',points:[
'Preanesthetic medicines: antacids, anticholinergics, antiemetics, antihistamines, benzodiazepines, opioids (selected use).',
'Inhaled general anesthetics: desflurane, halothane, isoflurane, nitrous oxide, sevoflurane.',
'IV general anesthetics: selected barbiturates, benzodiazepines, dexmedetomidine, etomidate, ketamine, propofol.',
'Neuromuscular blockers: cisatracurium, pancuronium, rocuronium, succinylcholine, vecuronium.',
'Local anesthetics—amides: bupivacaine, lidocaine, mepivacaine, ropivacaine.',
'Local anesthetics—esters: chloroprocaine, procaine, tetracaine.',
]},
{title:'3. Mechanism of action',points:[
'General anesthetics alter CNS signalling through multiple targets; mechanisms vary by agent.',
'Propofol and many anesthetics enhance inhibitory GABA-A signalling; ketamine antagonizes NMDA receptors; dexmedetomidine activates alpha-2 receptors.',
'Local anesthetics block voltage-gated sodium channels and prevent nerve impulse conduction.',
'Neuromuscular blockers act at nicotinic receptors at the neuromuscular junction.',
]},
{title:'4. Uses',points:[
'Inhaled/IV agents: induction or maintenance of anesthesia, depending on drug.',
'Local anesthetics: infiltration, nerve blocks, epidural/spinal and other regional techniques.',
'Neuromuscular blockers: controlled muscle relaxation during intubation or surgery; require airway/ventilation monitoring.',
]},
{title:'5. Side effects and adverse effects',points:[
'Hypotension, respiratory depression, nausea, vomiting and emergence effects.',
'Malignant hyperthermia susceptibility with selected agents; ketamine may cause emergence reactions and cardiovascular stimulation.',
'Local anesthetic systemic toxicity: neurologic symptoms, seizures and cardiac arrhythmias.',
'Neuromuscular blockers: paralysis, anaphylaxis and prolonged blockade; succinylcholine may cause hyperkalemia and malignant hyperthermia triggering.',
]},
{title:'6. Contraindications and cautions',points:[
'Agent-specific: malignant hyperthermia history for triggering anesthetics; local anesthetic allergy (particularly ester-related); cardiovascular, respiratory or hepatic/renal risk depending on agent.',
'Neuromuscular blockers require appropriate ventilation, monitoring and reversal/support facilities.',
'Ketamine and other agents require patient-specific assessment.',
]},
{title:'7. Drug interactions',points:[
'Anesthetic agents and opioids/sedatives may synergize in respiratory and cardiovascular depression.',
'Neuromuscular blockers interact with aminoglycosides, magnesium and other agents that affect neuromuscular transmission.',
'Local anesthetics may interact with medicines affecting cardiac conduction or metabolism.',
'MAOIs, antidepressants and sympathomimetics can modify anesthetic responses; assess agent-specific interactions.',
]},
]},
14:{number:14,title:'Opioid Analgesics and Antagonists',overview:'Opioids act on opioid receptors to reduce pain signalling; antagonists reverse selected opioid effects.',sections:[
{title:'1. Indication',points:[
'Moderate-to-severe pain, anesthesia-related analgesia, selected cough/diarrhoea indications and treatment of opioid toxicity or dependence, depending on agent.',
]},
{title:'2. Groups and examples of drugs',points:[
'Strong agonists: alfentanil, fentanyl, hydrocodone, hydromorphone, meperidine, methadone, morphine, oxycodone, oxymorphone, remifentanil, sufentanil.',
'Moderate/low agonist: codeine.',
'Mixed/partial agonists: buprenorphine, butorphanol, nalbuphine, pentazocine.',
'Antagonists: naloxone, naltrexone.',
'Other analgesics: tapentadol, tramadol.',
]},
{title:'3. Mechanism of action',points:[
'Opioid agonists activate mu, kappa or delta opioid receptors and modulate pain signalling.',
'Partial agonists have lower intrinsic activity at selected receptors; mixed agonists may activate one receptor subtype while antagonizing another.',
'Naloxone and naltrexone antagonize opioid receptors.',
]},
{title:'4. Uses',points:[
'Analgesia in selected acute and chronic pain settings; perioperative analgesia; selected palliative care.',
'Buprenorphine and methadone are used in opioid-use-disorder treatment.',
'Naloxone reverses opioid overdose; naltrexone is used in selected opioid/alcohol-use-disorder treatment.',
'Some agents have specific cough, diarrhoea or anesthesia indications.',
]},
{title:'5. Side effects and adverse effects',points:[
'Constipation, nausea, vomiting, sedation, pruritus, urinary retention and miosis.',
'Respiratory depression, hypotension, dependence, tolerance and overdose.',
'Methadone may prolong QT; meperidine has neurotoxic metabolite risk; tramadol may cause seizures and serotonin syndrome.',
'Buprenorphine may precipitate withdrawal if initiated inappropriately in opioid-dependent patients.',
]},
{title:'6. Contraindications and cautions',points:[
'Respiratory depression, severe asthma in an unmonitored setting, bowel obstruction and other agent-specific contraindications.',
'Use caution with head injury, sleep apnea, hepatic/renal impairment, older age, pregnancy and substance-use risk.',
'Antagonists may precipitate withdrawal in opioid-dependent patients.',
]},
{title:'7. Drug interactions',points:[
'Opioids plus benzodiazepines, alcohol or other CNS depressants increase respiratory depression and sedation.',
'Serotonergic drugs may increase serotonin-syndrome risk with tramadol and selected opioids.',
'CYP inhibitors/inducers can alter exposure to certain opioids.',
'QT-prolonging drugs may add risk with methadone.',
]},
]},
15:{number:15,title:'Drugs of Abuse',overview:'Substances that may alter mood, perception, consciousness or CNS activity and may cause misuse, dependence or harm.',sections:[
{title:'1. Indication / overview',points:[
'This class is primarily a toxicology and pharmacology overview; some listed substances have legitimate clinical uses under controlled circumstances.',
]},
{title:'2. Groups and examples of drugs',points:[
'Stimulants: amphetamines, cocaine, MDMA, synthetic cathinones.',
'Hallucinogens: LSD, cannabis/marijuana, synthetic cannabinoids.',
'Other drugs of abuse: ethanol and prescription drugs, particularly opioids.',
]},
{title:'3. Mechanism of action',points:[
'Stimulants alter catecholamine signalling and CNS activity.',
'Hallucinogens act on neurotransmitter systems that influence perception and cognition; mechanisms vary.',
'Cannabinoids act mainly through cannabinoid receptors.',
'Ethanol affects multiple neurotransmitter systems.',
'Prescription substances have drug-specific mechanisms.',
]},
{title:'4. Uses',points:[
'Some stimulants and cannabinoid-derived products have approved medical uses; opioid medicines have legitimate analgesic uses.',
'Ethanol and many listed substances are not routine therapeutic agents.',
]},
{title:'5. Side effects and adverse effects',points:[
'Impaired judgement, agitation, anxiety, insomnia, tachycardia, hypertension, coordination impairment, cognitive effects, dependence and withdrawal.',
'Potential severe complications include cardiovascular, neurological, psychiatric and overdose-related effects.',
]},
{title:'6. Contraindications and cautions',points:[
'Risks vary by substance and include cardiovascular disease, psychiatric conditions, pregnancy, organ impairment and interactions with other substances.',
]},
{title:'7. Drug interactions',points:[
'Stimulants combined with other stimulants can increase cardiovascular toxicity.',
'Alcohol combined with CNS depressants can cause severe CNS/respiratory depression.',
'Opioids combined with benzodiazepines or other sedatives increase overdose risk.',
'Cannabinoids combined with CNS depressants may increase impairment.',
]},
]},
16:{number:16,title:'CNS Stimulants (Psychomotor Stimulants)',overview:'Agents that increase CNS activity, alertness, wakefulness or selected cognitive functions; mechanisms and clinical roles vary.',sections:[
{title:'1. Indication',points:[
'ADHD, narcolepsy, selected excessive sleepiness, smoking cessation and other agent-specific uses.',
]},
{title:'2. Groups and examples of drugs',points:[
'Psychomotor stimulant/source list: amphetamine (Adderall); armodafinil (Nuvigil); atomoxetine (Strattera); caffeine (Cafcit, No Doz, Vivarin); cocaine; dexmethylphenidate (Focalin); dextroamphetamine (Dexedrine, Dextrostat); lisdexamfetamine (Vyvanse); methamphetamine (Desoxyn); methylphenidate (Ritalin, Concerta, Daytrana); modafinil (Provigil); nicotine (Nicoderm CQ, Nicorette, Nicotrol); theophylline (Elixophyllin, Theo-24, Theochron, Uniphyl); varenicline (Chantix).',
'Note: Atomoxetine and varenicline are included in the source list but are not conventional psychostimulants; their pharmacology and therapeutic role differ.',
]},
{title:'3. Mechanism of action',points:[
'Amphetamine derivatives increase catecholamine signalling; methylphenidate inhibits dopamine/norepinephrine reuptake.',
'Modafinil/armodafinil promote wakefulness through multiple pathways.',
'Caffeine antagonizes adenosine receptors; nicotine activates nicotinic receptors.',
'Theophylline antagonizes adenosine receptors and has other actions.',
'Atomoxetine inhibits norepinephrine reuptake; varenicline is a partial agonist at selected nicotinic receptors.',
'Cocaine inhibits monoamine reuptake transporters.',
]},
{title:'4. Uses',points:[
'ADHD: selected amphetamine derivatives, methylphenidate and atomoxetine.',
'Narcolepsy/excessive sleepiness: selected wake-promoting agents.',
'Smoking cessation: nicotine replacement and varenicline.',
'Caffeine: selected neonatal and other specific clinical indications.',
'Theophylline: limited, selected respiratory indications.',
]},
{title:'5. Side effects and adverse effects',points:[
'Insomnia, anxiety, restlessness, headache, tachycardia, hypertension, appetite suppression, nausea and tremor.',
'Serious effects may include arrhythmias, seizures, psychosis, cardiovascular toxicity and dependence/misuse.',
'Theophylline has a narrow therapeutic range and toxicity may be serious.',
]},
{title:'6. Contraindications and cautions',points:[
'Agent-specific; consider uncontrolled hypertension, cardiovascular disease, arrhythmias, hyperthyroidism, glaucoma, seizure risk, psychiatric conditions and recent/concurrent MAOI use where relevant.',
'Check individual product information and patient factors.',
]},
{title:'7. Drug interactions',points:[
'Selected stimulants with MAOIs can cause severe reactions.',
'Other sympathomimetics may add cardiovascular stimulation.',
'Caffeine with stimulants may increase insomnia, tremor and tachycardia.',
'CYP1A2 inhibitors/inducers can alter theophylline concentrations.',
'Nicotine and smoking cessation may change the effect of medicines affected by tobacco smoke.',
]},
]},
};