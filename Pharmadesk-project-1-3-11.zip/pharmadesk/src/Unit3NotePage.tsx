import { unit3Notes } from './unit3Notes';
import { BookOpen, ShieldAlert } from 'lucide-react';

const groupPalette=['#0D9488','#2563EB','#D97706','#7C3AED','#DB2777','#0891B2','#65A30D'];
function parseDrugGroups(points:string[]) {
  return points.map((point,index)=>{
    const colon=point.indexOf(':');
    let title=colon>0?point.slice(0,colon).trim():`Drug examples ${index+1}`;
    let content=colon>0?point.slice(colon+1).trim():point.trim();
    // Keep the special explanatory note intact rather than treating it as a drug chip list.
    if(title==='Note') return {title,items:[content],note:true};
    const chunks=content.split(';').map(x=>x.trim()).filter(Boolean);
    const items=chunks.flatMap(chunk=>chunk.split(',').map(x=>x.trim()).filter(Boolean));
    return {title,items,note:false};
  });
}
function Point({text}:{text:string}) {
  const i=text.indexOf(':');
  return <li>{i>0&&i<100?<><strong className="unit3-keyterm">{text.slice(0,i+1)}</strong> {text.slice(i+1).trim()}</>:text}</li>;
}
export function Unit3NotePage({number,onBack}:{number:number;onBack:()=>void}) {
  const note=unit3Notes[number];
  if(!note) return null;
  return <section className="chapter-detail unit-note-page unit3-note-page">
    <button className="back" onClick={onBack}>← Back to units</button>
    <div className="unit-note-kicker">UNIT III · DRUGS AFFECTING THE CENTRAL NERVOUS SYSTEM</div>
    <div className="unit-note-heading"><span>CLASS {note.number}</span><h1>{note.title}</h1><p>{note.overview}</p></div>
    {note.sections.map((section,index)=><section className="unit-note-section" key={section.title}>
      <h2><span>{index+1}</span>{section.title}</h2>
      {index===1 ? <div className="unit3-drug-groups">{parseDrugGroups(section.points).map((group,gi)=><div className="unit-note-group unit3-drug-group" key={`${group.title}-${gi}`} style={{'--unit3-accent':groupPalette[gi%groupPalette.length] as string} as React.CSSProperties}><h3>{group.title}</h3>{group.note?<p className="unit3-group-note">{group.items[0]}</p>:<div className="unit3-drug-list">{group.items.map((item,ii)=><span className="unit3-drug-chip" key={`${item}-${ii}`}>{item}</span>)}</div>}</div>)}</div> : <ul>{section.points.map((point,i)=><Point key={i} text={point}/>)}</ul>}
    </section>)}
    <div className="unit-note-warning"><ShieldAlert size={17}/><p><b>Educational reference only.</b> These concise notes support study and do not replace current prescribing information, clinical guidelines or professional judgement. Confirm drug-specific contraindications, doses and interactions from trusted references.</p></div>
    <div className="unit-note-footer"><BookOpen size={15}/> Pharmadesk · Unit III · Class {note.number}</div>
  </section>;
}
