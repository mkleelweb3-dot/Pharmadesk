import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  Accessibility, Activity, ArrowLeft, Baby, Bone, BookOpen, Brain, CheckCircle2, ChevronRight, Download,
  Droplets, ExternalLink, Eye, Heart, HeartPulse, Info, Languages, Menu, Monitor, Phone, Pill,
  RefreshCw, Search, Settings as SettingsIcon, ShieldCheck, Sun, Wind, Wifi,
  WifiOff, X, ZoomIn, Dna, Shield, Scan, Stethoscope
} from 'lucide-react';
import { drugClasses, type DrugClass } from './data';
import './style.css';

const systems = [...new Set(drugClasses.map(d => d.system))];
const haSystem: Record<string,string> = {
  'Gastrointestinal':'Tsarin narkar da abinci','Respiratory':'Tsarin numfashi','Cardiovascular':'Tsarin zuciya da jijiyoyin jini',
  'Nervous system':'Tsarin jijiyoyi','Endocrine':'Tsarin hormones','Reproductive':'Tsarin haihuwa',
  'Musculoskeletal':'Tsarin ƙashi da tsoka','Anti-infectives':'Magungunan yaƙi da ƙwayoyin cuta',
  'Hematology':'Tsarin jini','Dermatology':'Fannin fata','Ophthalmology & ENT':'Ido, kunne, hanci da maƙogwaro',
  'Renal & Urology':'Koda da hanyoyin fitsari','Immunology & Oncology':'Garkuwar jiki da kansa'
};

const systemMeta: Record<string,{title:string;subtitle:string;haTitle:string;haSubtitle:string;icon:ReactNode;labels:string[];accent:string}> = {
  'Gastrointestinal':{title:'Gastrointestinal Drugs',subtitle:'Explore medicines related to digestion, acid control and gut function.',haTitle:'Magungunan Tsarin Narkar da Abinci',haSubtitle:'Binciki magungunan da suka shafi narkar da abinci da aikin hanji.',icon:<Activity/>,labels:['Oesophagus','Stomach','Liver','Pancreas','Small intestine','Large intestine'],accent:'#d28a62'},
  'Respiratory':{title:'Respiratory Drugs',subtitle:'Explore medicines used in airway and lung conditions.',haTitle:'Magungunan Tsarin Numfashi',haSubtitle:'Binciki magungunan da suka shafi hanyoyin iska da huhu.',icon:<Wind/>,labels:['Nasal passages','Trachea','Bronchi','Right lung','Left lung'],accent:'#62a9a0'},
  'Cardiovascular':{title:'Cardiovascular Drugs',subtitle:'Explore medicines affecting the heart and blood vessels.',haTitle:'Magungunan Zuciya da Jijiyoyin Jini',haSubtitle:'Binciki magungunan da ke shafar zuciya da jijiyoyin jini.',icon:<HeartPulse/>,labels:['Heart','Aorta','Arteries','Veins'],accent:'#c96f78'},
  'Nervous system':{title:'Nervous System Drugs',subtitle:'Explore medicines affecting the brain, spinal cord and nerves.',haTitle:'Magungunan Tsarin Jijiyoyi',haSubtitle:'Binciki magungunan da ke shafar kwakwalwa da jijiyoyi.',icon:<Brain/>,labels:['Brain','Spinal cord','Peripheral nerves'],accent:'#9b87c8'},
  'Endocrine':{title:'Endocrine Drugs',subtitle:'Explore medicines related to hormones and endocrine glands.',haTitle:'Magungunan Tsarin Hormones',haSubtitle:'Binciki magungunan da suka shafi hormones da glands.',icon:<Dna/>,labels:['Pituitary','Thyroid','Adrenal glands','Pancreas'],accent:'#b69a59'},
  'Reproductive':{title:'Reproductive System Drugs',subtitle:'Explore medicines related to reproductive health.',haTitle:'Magungunan Tsarin Haihuwa',haSubtitle:'Binciki magungunan da suka shafi lafiyar tsarin haihuwa.',icon:<Baby/>,labels:['Ovaries','Uterus','Prostate','Testes'],accent:'#c47d9a'},
  'Musculoskeletal':{title:'Musculoskeletal Drugs',subtitle:'Explore medicines related to bones, joints and muscles.',haTitle:'Magungunan Ƙashi da Tsoka',haSubtitle:'Binciki magungunan da suka shafi ƙashi, gaɓoɓi da tsoka.',icon:<Bone/>,labels:['Bones','Joints','Skeletal muscles'],accent:'#b58d66'},
  'Anti-infectives':{title:'Anti-infective Drugs',subtitle:'Explore medicines used against bacterial, viral, fungal and parasitic infections.',haTitle:'Magungunan Yaƙi da Ƙwayoyin Cuta',haSubtitle:'Binciki magungunan yaƙi da bacteria, virus, fungi da parasites.',icon:<Shield/>,labels:['Bacteria','Viruses','Fungi','Parasites'],accent:'#6caa83'},
  'Hematology':{title:'Hematology Drugs',subtitle:'Explore medicines related to blood and clotting.',haTitle:'Magungunan Tsarin Jini',haSubtitle:'Binciki magungunan da suka shafi jini da daskarewarsa.',icon:<Droplets/>,labels:['Red blood cells','White blood cells','Platelets','Plasma'],accent:'#c66b71'},
  'Dermatology':{title:'Dermatology Drugs',subtitle:'Explore medicines used for skin conditions.',haTitle:'Magungunan Fata',haSubtitle:'Binciki magungunan da ake amfani da su wajen matsalolin fata.',icon:<Scan/>,labels:['Epidermis','Dermis','Hair follicle','Sweat gland'],accent:'#bd9971'},
  'Ophthalmology & ENT':{title:'Ophthalmology & ENT Drugs',subtitle:'Explore medicines related to the eyes, ears, nose and throat.',haTitle:'Magungunan Ido, Kunne, Hanci da Maƙogwaro',haSubtitle:'Binciki magungunan da suka shafi ido, kunne, hanci da maƙogwaro.',icon:<Eye/>,labels:['Eye','Ear','Nasal cavity','Throat'],accent:'#6f9eb6'},
  'Renal & Urology':{title:'Renal & Urology Drugs',subtitle:'Explore medicines related to kidney and urinary tract function.',haTitle:'Magungunan Koda da Hanyoyin Fitsari',haSubtitle:'Binciki magungunan da suka shafi koda da hanyoyin fitsari.',icon:<Activity/>,labels:['Kidneys','Ureters','Bladder','Urethra'],accent:'#7c9dc0'},
  'Immunology & Oncology':{title:'Immunology & Oncology Drugs',subtitle:'Explore medicines related to immune function and cancer care.',haTitle:'Magungunan Garkuwar Jiki da Oncology',haSubtitle:'Binciki magungunan da suka shafi garkuwar jiki da kula da kansa.',icon:<Stethoscope/>,labels:['Lymph nodes','Thymus','Spleen','Bone marrow'],accent:'#8b9c75'}
};
type Theme = 'light' | 'dark' | 'system';
type FontSize = 'small' | 'normal' | 'large';
type Preferences = {
  theme: Theme;
  fontSize: FontSize;
  allowZoom: boolean;
  compactCards: boolean;
  highContrast: boolean;
  reduceMotion: boolean;
};
const defaultPreferences: Preferences = {
  theme: 'light', fontSize: 'normal', allowZoom: false,
  compactCards: false, highContrast: false, reduceMotion: false
};
function readPreferences(): Preferences {
  try { return { ...defaultPreferences, ...JSON.parse(localStorage.getItem('pd-settings') || '{}') }; }
  catch { return defaultPreferences; }
}

function App() {
  const [lang,setLang] = useState<'en'|'ha'>(() => (localStorage.getItem('pd-lang') as 'en'|'ha') || 'ha');
  const [preferences,setPreferences] = useState<Preferences>(readPreferences);
  const [search,setSearch] = useState('');
  const [system,setSystem] = useState('All');
  const [detail,setDetail] = useState<DrugClass|null>(null);
  const [saved,setSaved] = useState<string[]>(() => JSON.parse(localStorage.getItem('pd-saved') || '[]'));
  const [onlySaved,setOnlySaved] = useState(false);
  const [online,setOnline] = useState(navigator.onLine);
  const [navOpen,setNavOpen] = useState(false);
  const [view,setView] = useState<'library'|'settings'>('library');
  const [cacheReady,setCacheReady] = useState(false);
  const [cacheMessage,setCacheMessage] = useState('');
  const [diagramOpen,setDiagramOpen] = useState(false);
  const ha = lang === 'ha';
  const t = (en:string,haText:string) => ha ? haText : en;

  useEffect(() => { localStorage.setItem('pd-lang',lang); document.documentElement.lang = lang; },[lang]);
  useEffect(() => { localStorage.setItem('pd-saved',JSON.stringify(saved)); },[saved]);
  useEffect(() => { localStorage.setItem('pd-settings',JSON.stringify(preferences)); },[preferences]);
  useEffect(() => {
    const root = document.documentElement;
    const applyTheme = () => {
      const resolved = preferences.theme === 'system'
        ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
        : preferences.theme;
      root.dataset.theme = resolved;
    const themeMeta = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
    if (themeMeta) themeMeta.content = resolved === 'dark' ? '#111b19' : '#102b2a';
    };
    applyTheme();
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    media.addEventListener?.('change', applyTheme);
    return () => media.removeEventListener?.('change', applyTheme);
  },[preferences.theme]);
  useEffect(() => {
    const viewport = document.querySelector<HTMLMetaElement>('meta[name="viewport"]');
    if (viewport) viewport.content = preferences.allowZoom
      ? 'width=device-width, initial-scale=1.0, viewport-fit=cover'
      : 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover';
  },[preferences.allowZoom]);
  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener('online',update); window.addEventListener('offline',update);
    const checkCache = async () => {
      try {
        const keys = await caches.keys();
        setCacheReady(keys.some(key => key.startsWith('pharmadesk-cache-')));
      } catch { setCacheReady(false); }
    };
    checkCache();
    navigator.serviceWorker?.ready.then(checkCache).catch(()=>{});
    return () => { window.removeEventListener('online',update); window.removeEventListener('offline',update); };
  },[]);

  const results = useMemo(() => drugClasses.filter(d => {
    const q = search.toLowerCase();
    return (system === 'All' || d.system === system) && (!onlySaved || saved.includes(d.id)) &&
      [d.name,d.nameHa,d.system,d.description,...d.examples,...d.subgroups].join(' ').toLowerCase().includes(q);
  }),[search,system,onlySaved,saved]);
  const toggleSave = (id:string) => setSaved(old => old.includes(id) ? old.filter(x=>x!==id) : [...old,id]);
  const title = (d:DrugClass) => ha ? d.nameHa : d.name;
  const sysTitle = (s:string) => ha ? (haSystem[s] || s) : s;
  const openLibrary = () => { setView('library'); setDetail(null); setNavOpen(false); };
  const openSettings = () => { setView('settings'); setDetail(null); setNavOpen(false); };
  const updatePreference = <K extends keyof Preferences>(key:K,value:Preferences[K]) =>
    setPreferences(old => ({...old,[key]:value}));
  const refreshOfflineData = async () => {
    setCacheMessage(t('Checking for app updates…','Ana duba sabbin bayanan manhaja…'));
    try {
      const registration = await navigator.serviceWorker?.getRegistration();
      if (!registration) {
        setCacheMessage(t('Offline service is not registered yet. Open the app online and try again.','Ba a kunna offline service ba tukuna. Buɗe app da internet sannan a sake gwadawa.'));
        return;
      }
      await registration.update();
      const keys = await caches.keys();
      setCacheReady(keys.some(key => key.startsWith('pharmadesk-cache-')));
      setCacheMessage(t('Update check completed. Reopen Pharmadesk if a new version is available.','An kammala duba update. Sake buɗe Pharmadesk idan akwai sabon version.'));
    } catch {
      setCacheMessage(t('Could not check for updates. Please try again while online.','An kasa duba update. Gwada sakewa kana da internet.'));
    }
  };
  const exportSaved = () => {
    const selected = drugClasses.filter(item => saved.includes(item.id));
    const blob = new Blob([JSON.stringify({ app:'Pharmadesk', exportedAt:new Date().toISOString(), saved:selected },null,2)],{type:'application/json'});
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a'); link.href = url; link.download = 'pharmadesk-saved-classes.json'; link.click(); URL.revokeObjectURL(url);
  };

  return <div className={`shell font-${preferences.fontSize}${preferences.compactCards?' compact-cards':''}${preferences.highContrast?' high-contrast':''}${preferences.reduceMotion?' reduce-motion':''}`}>
    <header className="topbar">
      <button className="brand" onClick={openLibrary}><span className="logo"><Pill/></span><span><b>pharmadesk</b><small>PHARMACY KNOWLEDGE BASE</small></span></button>
      <div className="top-actions">
        <span className={online?'status online':'status offline'}>{online?<Wifi size={15}/>:<WifiOff size={15}/>} {online?t('Online','Akwai internet') : t('Offline ready','A shirye offline')}</span>
        <button className="lang" onClick={()=>setLang(ha?'en':'ha')} aria-label={t('Switch language','Canza harshe')}><Languages size={16}/>{ha?'English':'Hausa'}</button>
        <button className="saved-head" onClick={()=>{setOnlySaved(!onlySaved);setView('library');setDetail(null);}}><Heart size={16}/><span>{t('Saved','Abubuwan da aka ajiye')}</span> {saved.length}</button>
        <button className="settings-head" onClick={openSettings} aria-label={t('Settings','Saituna')}><SettingsIcon size={19}/></button>
        <button className="hamb" onClick={()=>setNavOpen(!navOpen)} aria-label="Toggle navigation">{navOpen?<X/>:<Menu/>}</button>
      </div>
    </header>
    <div className="body">
      <aside className={navOpen?'sidebar open':'sidebar'}>
        <div className="nav-label">{t('LIBRARY','TASKAR BAYANI')}</div>
        <button className={view==='library'&&system==='All'&&!onlySaved?'nav-item active':'nav-item'} onClick={()=>{setSystem('All');setOnlySaved(false);setSearch('');openLibrary();}}><BookOpen size={16}/>{t('Home','Gida')}</button>
        <div className="nav-label systems-label">{t('BODY SYSTEMS','TSARIN JIKI')}</div>
        {systems.map(s=><button key={s} className={system===s&&!onlySaved&&view==='library'?'nav-item active':'nav-item'} onClick={()=>{setSystem(s);setOnlySaved(false);setView('library');setDetail(null);setNavOpen(false);}}><i/>{sysTitle(s)}<span>{drugClasses.filter(d=>d.system===s).length}</span></button>)}
        <div className="sidebar-bottom">
          <button className={view==='settings'?'nav-item active':'nav-item'} onClick={openSettings}><SettingsIcon size={16}/>{t('Settings','Saituna')}</button>
          <div className="safety-note"><ShieldCheck size={17}/><div><b>{t('Study reference','Bayanan karatu')}</b><p>{t('Educational use only. Verify clinical decisions with trusted references.','Don karatu ne kawai. Tabbatar da shawarar asibiti daga sahihan littattafai da jagorori.')}</p></div></div>
        </div>
      </aside>
      <main className="main">
        {view==='settings' ? <section className="settings-page">
          <button className="back" onClick={openLibrary}><ArrowLeft size={16}/>{t('Back to library','Komawa taskar bayanai')}</button>
          <div className="settings-heading"><div className="kicker">{t('PHARMADESK PREFERENCES','SAITUNAN PHARMADESK')}</div><h1>{t('Settings','Saituna')}</h1><p>{t('Make Pharmadesk comfortable for your study and reference workflow.','Daidaita Pharmadesk domin ya dace da karatunka da bincikensa.')}</p></div>

          <section className="settings-group">
            <div className="settings-group-title"><Monitor size={18}/><div><h2>{t('Display & appearance','Nuni da kamanni')}</h2><p>{t('Control the look and readability of the app.','Sarrafa kamanni da sauƙin karanta manhaja.')}</p></div></div>
            <div className="setting-row"><div className="setting-copy"><b>{t('Theme','Yanayin launi')}</b><small>{t('Choose light, dark or follow your device.','Zaɓi haske, duhu ko bin saitin wayarka.')}</small></div><select value={preferences.theme} onChange={e=>updatePreference('theme',e.target.value as Theme)}><option value="light">{t('Light','Haske')}</option><option value="dark">{t('Dark','Duhu')}</option><option value="system">{t('System default','Saitin waya')}</option></select></div>
            <div className="setting-row"><div className="setting-copy"><b>{t('Text size','Girman rubutu')}</b><small>{t('Increase text without zooming the whole page.','Ƙara rubutu ba tare da zoom na shafi ba.')}</small></div><select value={preferences.fontSize} onChange={e=>updatePreference('fontSize',e.target.value as FontSize)}><option value="small">{t('Small','Ƙarami')}</option><option value="normal">{t('Normal','Matsakaici')}</option><option value="large">{t('Large','Babba')}</option></select></div>
            <ToggleRow icon={<ZoomIn size={17}/>} title={t('Allow pinch zoom','Bada damar zoom')} description={t('Off prevents accidental pinch zoom. Text size remains adjustable above.','Idan an kashe, ba za a iya yin pinch zoom ba. Ana iya canza girman rubutu a sama.')} checked={preferences.allowZoom} onChange={v=>updatePreference('allowZoom',v)} />
            <ToggleRow icon={<BookOpen size={17}/>} title={t('Compact drug cards','Takaita katunan drug classes')} description={t('Show more classes on one screen.','Nuna ƙarin classes a allo guda.')} checked={preferences.compactCards} onChange={v=>updatePreference('compactCards',v)} />
          </section>

          <section className="settings-group">
            <div className="settings-group-title"><Languages size={18}/><div><h2>{t('Language','Harshe')}</h2><p>{t('Choose the language used across Pharmadesk.','Zaɓi harshen da Pharmadesk zai yi amfani da shi.')}</p></div></div>
            <div className="setting-row"><div className="setting-copy"><b>{t('App language','Harshen manhaja')}</b><small>{t('Your choice is saved on this device.','Zaɓinka zai kasance ajiye a wayarka.')}</small></div><select value={lang} onChange={e=>setLang(e.target.value as 'en'|'ha')}><option value="en">English</option><option value="ha">Hausa</option></select></div>
          </section>

          <section className="settings-group">
            <div className="settings-group-title"><Wifi size={18}/><div><h2>{t('Offline & storage','Offline da ajiya')}</h2><p>{t('Check whether offline resources are available on this device.','Duba ko bayanan offline suna ajiye a wannan waya.')}</p></div></div>
            <div className="offline-status"><span className={cacheReady?'state-dot ready':'state-dot'}></span><div><b>{cacheReady?t('Offline cache detected','An gano ajiyar offline'):t('Offline cache not confirmed','Ba a tabbatar da ajiyar offline ba')}</b><small>{online?t('You are currently online. Open the app once after updates to refresh its cached files.','Kana da internet yanzu. Buɗe app bayan update domin sabunta ajiyar fayiloli.'):t('You are offline. Previously cached app files may still be available.','Babu internet. Fayilolin da aka ajiye a baya na iya kasancewa.')}</small></div></div>
            <button className="action-button" onClick={refreshOfflineData} disabled={!online}><RefreshCw size={16}/>{t('Check for updates','Duba sabbin updates')}</button>
            {cacheMessage&&<p className="inline-message">{cacheMessage}</p>}
          </section>

          <section className="settings-group">
            <div className="settings-group-title"><Accessibility size={18}/><div><h2>{t('Accessibility','Sauƙin amfani')}</h2><p>{t('Adjust the interface for comfortable reading.','Daidaita fuskar manhaja domin sauƙin karatu.')}</p></div></div>
            <ToggleRow icon={<CheckCircle2 size={17}/>} title={t('High contrast','Bambancin launi mai ƙarfi')} description={t('Strengthen text and border contrast.','Ƙara bambancin rubutu da iyakokin abubuwa.')} checked={preferences.highContrast} onChange={v=>updatePreference('highContrast',v)} />
            <ToggleRow icon={<Sun size={17}/>} title={t('Reduce animations','Rage motsin abubuwa')} description={t('Reduce non-essential interface movement.','Rage motsin abubuwan da ba su da muhimmanci.')} checked={preferences.reduceMotion} onChange={v=>updatePreference('reduceMotion',v)} />
          </section>

          <section className="settings-group">
            <div className="settings-group-title"><Heart size={18}/><div><h2>{t('Personal data','Bayanan ka')}</h2><p>{t('Your saved classes are stored on this device.','Drug classes da ka ajiye suna cikin wannan wayar.')}</p></div></div>
            <div className="setting-row"><div className="setting-copy"><b>{t('Saved classes','Classes da aka ajiye')}</b><small>{saved.length} {t('saved items','abubuwan da aka ajiye')}</small></div><button className="action-button" onClick={exportSaved} disabled={saved.length===0}><Download size={15}/>{t('Export','Fitarwa')}</button></div>
          </section>

          <section className="settings-group about-group">
            <div className="settings-group-title"><Info size={18}/><div><h2>{t('About Pharmadesk','Game da Pharmadesk')}</h2><p>{t('Project information and founder contact.','Bayanan aikin da hanyar tuntuɓar wanda ya kafa shi.')}</p></div></div>
            <div className="about-brand"><span className="logo"><Pill/></span><div><b>Pharmadesk</b><small>{t('Your Pharmacy Knowledge Base','Taskar Ilimin Pharmacy')}</small></div></div>
            <div className="founder-card"><small>{t('FOUNDER OF PHARMADESK','WANDA YA KAFA PHARMADESK')}</small><h3>Pharm. Ibrahim Sulaiman Ibrahim</h3><p>MK LEEL</p></div>
            <a className="contact-link" href="tel:+2349049186575"><Phone size={16}/><span>+2349049186575</span><ExternalLink size={13}/></a>
            <a className="contact-link" href="https://x.com/Drx_mkleel" target="_blank" rel="noreferrer"><span className="x-mark">𝕏</span><span>@Drx_mkleel</span><ExternalLink size={13}/></a>
            <p className="disclaimer"><ShieldCheck size={15}/>{t('Educational reference only. It does not replace professional clinical judgement, official guidelines or a registered pharmacist’s advice.','Bayanan karatu ne kawai. Ba ya maye gurbin hukuncin kwararren ma’aikacin lafiya, jagororin hukuma ko shawarar pharmacist mai rijista.')}</p>
            <div className="version-line"><span>PHARMADESK</span><span>{t('Version 1.2 · Educational reference','Siga 1.1 · Bayanan ilimi')}</span></div>
          </section>
        </section> : detail ? <section className="detail">
          <button className="back" onClick={()=>setDetail(null)}><ArrowLeft size={16}/>{t('Back to library','Komawa jerin magunguna')}</button>
          <div className="kicker">{sysTitle(detail.system)}</div>
          <div className="detail-title"><div><h1>{title(detail)}</h1><p>{ha?detail.descriptionHa:detail.description}</p></div><button className={saved.includes(detail.id)?'heart saved':'heart'} onClick={()=>toggleSave(detail.id)}><Heart fill={saved.includes(detail.id)?'currentColor':'none'}/></button></div>
          <div className="panel"><h3>{t('Generic drug examples','Misalan sunayen magunguna na generic')}</h3><div className="drug-grid">{detail.examples.map(x=><div className="drug" key={x}><Pill size={16}/>{x}</div>)}</div></div>
          <div className="panel"><h3>{t('Subclasses / related groups','Ƙananan rukuni / masu alaƙa')}</h3><div className="tags">{detail.subgroups.map(x=><span key={x}>{x}</span>)}</div></div>
          <div className="warning"><ShieldCheck size={18}/><p>{t('Educational classification only. A medicine may belong to more than one class and may have multiple indications. This app does not provide dosing, diagnosis or prescribing advice.','Rarrabewa ce don ilimi kawai. Magani na iya kasancewa a rukuni fiye da ɗaya kuma yana iya samun amfani daban-daban. Wannan manhaja ba ta bayar da dose, diagnosis ko shawarar rubuta magani.')}</p></div>
        </section> : <>
          {system==='All'&&!onlySaved ? <>
            <section className="hero home-hero"><div className="hero-copy"><div className="eyebrow">● {t('YOUR PHARMACY KNOWLEDGE BASE','TASKAR ILIMIN PHARMACY')}</div><h1>{t('Learn pharmacy.','Koyi ilimin pharmacy.')}<br/><em>{t('One system at a time.','Tsari bayan tsari.')}</em></h1><p>{t('A focused space to explore body systems and understand the medicines connected to them — in Hausa and English.','Wurin koyon tsarin jiki da fahimtar magungunan da suka shafe su — da Hausa da Turanci.')}</p></div></section>
            <section className="home-welcome"><div className="home-welcome-icon"><BookOpen size={22}/></div><div><b>{t('Choose a body system to begin','Zaɓi tsarin jiki domin farawa')}</b><p>{t('Select any system from the Library menu. Each system has its own overview, anatomy diagram and drug classes.','Zaɓi tsarin jiki daga menu na gefe. Kowanne yana da bayaninsa, hoton anatomy da drug classes nasa.')}</p></div></section>
          </> : <>
            {system!=='All' && !onlySaved && <section className="system-hero" style={{'--system-accent':systemMeta[system]?.accent||'#69a994'} as React.CSSProperties}>
              <div className="system-hero-copy"><div className="eyebrow">● {t('BODY SYSTEM OVERVIEW','BAYANIN TSARIN JIKI')}</div><h1>{ha?(systemMeta[system]?.haTitle||sysTitle(system)):(systemMeta[system]?.title||system+' Drugs')}</h1><p>{ha?(systemMeta[system]?.haSubtitle||'Binciki wannan tsarin jiki da magungunansa.'):(systemMeta[system]?.subtitle||'Explore this body system and its related medicines.')}</p></div>
              <div className="system-art">{systemMeta[system]?.icon||<Activity size={62}/>}</div>
            </section>}
            <div className="section-head"><div><div className="kicker">{onlySaved?t('YOUR PERSONAL LIST','JERINKA'):t('EXPLORE THE LIBRARY','BINCIKI TASKAR BAYANI')}</div><h2>{onlySaved?t('Saved drug classes','Drug classes da aka ajiye'):sysTitle(system)}</h2><p>{results.length} {t('classes','rukuni')}</p></div></div>
            {system!=='All'&&!onlySaved && <button className="diagram-preview" onClick={()=>setDiagramOpen(true)}><div className="diagram-thumb"><AnatomyDiagram system={system} compact/></div><div className="diagram-copy"><small>{t('ANATOMY QUICK VIEW','DUBAN ANATOMY')}</small><b>{t('View labelled system diagram','Duba hoton tsarin jiki mai labels')}</b><span>{t('Tap to open the full study diagram','Danna domin buɗe cikakken diagram')}</span></div><ChevronRight size={19}/></button>}
            <div className="tools"><label className="search"><Search size={18}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder={t('Search drug, class or body system...','Nemo drug, class ko tsarin jiki...')}/></label><select value={system} onChange={e=>{setSystem(e.target.value);setOnlySaved(false);}}><option value="All">{t('All systems','Dukkan systems')}</option>{systems.map(s=><option key={s} value={s}>{sysTitle(s)}</option>)}</select></div>
            {results.length?<div className="grid">{results.map(d=><article key={d.id} className="card" onClick={()=>setDetail(d)}><div className="card-top"><span>{sysTitle(d.system)}</span><button onClick={e=>{e.stopPropagation();toggleSave(d.id);}} aria-label="Save"><Heart size={17} fill={saved.includes(d.id)?'currentColor':'none'}/></button></div><h3>{title(d)}</h3><p>{ha?d.descriptionHa:d.description}</p><div className="examples"><small>{t('EXAMPLES','MISALAI')}</small>{d.examples.slice(0,3).join(' · ')}{d.examples.length>3?' +':''}</div><div className="card-foot">{d.examples.length} {t('examples','misalai')}<b>{t('Explore','Duba')} <ChevronRight size={14}/></b></div></article>)}</div>:<div className="empty"><Search size={30}/><h3>{t('No matching classes','Ba a sami rukuni mai dacewa ba')}</h3><p>{t('Try another keyword or clear the filters.','Gwada wata kalma ko cire filters.')}</p><button onClick={()=>{setSearch('');setSystem('All');setOnlySaved(false);}}>{t('Clear filters','Cire filters')}</button></div>}
          </>}
        </>}
        {diagramOpen && system!=='All' && <div className="diagram-overlay" role="dialog" aria-modal="true" aria-label="Anatomy diagram" onClick={()=>setDiagramOpen(false)}><div className="diagram-modal" onClick={e=>e.stopPropagation()}><div className="diagram-modal-head"><div><small>{t('ANATOMY STUDY DIAGRAM','HOTON KARATUN ANATOMY')}</small><h2>{sysTitle(system)}</h2></div><button onClick={()=>setDiagramOpen(false)} aria-label="Close diagram"><X/></button></div><AnatomyDiagram system={system}/><p className="diagram-disclaimer">{t('Simplified educational overview. Not to scale; verify anatomical details with a recognised anatomy reference.','Sauƙaƙƙen hoton karatu ne. Ba a auna shi da girman gaske ba; tabbatar da cikakkun bayanai daga ingantaccen littafin anatomy.')}</p></div></div>}
        <footer><span>PHARMADESK · {t('LEARN WITH CLARITY','ILIMI CIKIN SAUƘI')}</span><span>{t('Educational reference · Not a prescribing tool','Bayanan ilimi · Ba kayan rubuta magani ba')}</span></footer>
      </main>
    </div>
  </div>;
}


function AnatomyDiagram({system,compact=false}:{system:string;compact?:boolean}) {
  const labels=systemMeta[system]?.labels||['Main structures','Related organs'];
  const accent=systemMeta[system]?.accent||'#6caa95';
  return <svg className={compact?'anatomy-svg compact':'anatomy-svg'} viewBox="0 0 560 310" role="img" aria-label={`${system} simplified labelled anatomy overview`}>
    <defs><linearGradient id="bodyTint" x1="0" x2="1"><stop stopColor="#e8f2ed"/><stop offset="1" stopColor="#d3e6dc"/></linearGradient></defs>
    <path d="M280 27c-23 0-37 17-37 39 0 18 10 32 24 38l-12 18-54 17c-21 7-34 25-37 48l-12 91h256l-12-91c-3-23-16-41-37-48l-54-17-12-18c14-6 24-20 24-38 0-22-14-39-37-39z" fill="url(#bodyTint)" stroke="#a8c8b7" strokeWidth="2"/>
    <path d="M255 120v126M305 120v126" stroke="#b7cec2" strokeWidth="2" strokeDasharray="4 5"/>
    <g fill={accent} stroke="#fff" strokeWidth="2">
      {system==='Gastrointestinal'?<><path d="M250 135c-15-13-34-4-31 13 2 13 17 16 27 10 10-6 15-17 4-23z"/><path d="M278 157c-16-9-25 6-19 20 4 10 19 15 30 5 12-11 7-20-11-25z"/><path d="M263 190c-18-12-31 4-21 17 8 10 24 9 34 1 9-8 2-14-13-18z"/><path d="M300 190c-18-10-30 7-20 19 9 10 24 7 33-2 8-8 1-13-13-17z"/></>:system==='Respiratory'?<><path d="M278 122v49c-23-28-45-18-48 15-3 34 8 49 31 38 16-8 17-30 17-54z"/><path d="M282 122v49c23-28 45-18 48 15 3 34-8 49-31 38-16-8-17-30-17-54z"/></>:system==='Cardiovascular'?<path d="M280 154c-18-23-48-7-38 17 7 17 38 38 38 38s31-21 38-38c10-24-20-40-38-17z"/>:system==='Nervous system'?<><path d="M254 68c-22-15-42 5-31 25-14 13-4 34 13 34 6 17 29 13 37 0V76z"/><path d="M306 68c22-15 42 5 31 25 14 13 4 34-13 34-6 17-29 13-37 0V76z"/><path d="M280 124v112" stroke={accent} strokeWidth="8"/></>:<><ellipse cx="280" cy="165" rx="42" ry="30"/><path d="M248 204q32 22 64 0" fill="none" stroke={accent} strokeWidth="8"/></>}
    </g>
    {!compact && labels.slice(0,6).map((label,i)=>{const left=i%2===0;const y=65+Math.floor(i/2)*75;return <g key={label}><path d={left?`M${left?245:315} ${y+10} L${left?175:385} ${y+10}`:`M315 ${y+10} L385 ${y+10}`} fill="none" stroke={accent} strokeWidth="1.5"/><circle cx={left?245:315} cy={y+10} r="4" fill={accent}/><rect x={left?14:386} y={y-5} width="150" height="30" rx="8" fill="#fff" stroke="#dce9e1"/><text x={left?25:397} y={y+14} fontSize="11" fill="#38574d">{label}</text></g>})}
    {compact&&<text x="280" y="287" textAnchor="middle" fontSize="13" fill="#52776a">Tap to view labelled anatomy</text>}
  </svg>;
}

function ToggleRow({icon,title,description,checked,onChange}:{icon:ReactNode;title:string;description:string;checked:boolean;onChange:(value:boolean)=>void}) {
  return <div className="setting-row toggle-row"><div className="toggle-icon">{icon}</div><div className="setting-copy"><b>{title}</b><small>{description}</small></div><button className={checked?'switch on':'switch'} role="switch" aria-checked={checked} onClick={()=>onChange(!checked)}><span/></button></div>;
}

export default App;
