import { unit3Notes } from './unit3Notes';
import { BookOpen, ShieldAlert } from 'lucide-react';

export function Unit3NotePage({number,onBack}:{number:number;onBack:()=>void}) {
  const note=unit3Notes[number];
  if(!note) return null;
  return <section className="chapter-detail unit-note-page unit3-note-page">
    <button className="back" onClick={onBack}>← Back to units</button>
    <div className="unit-note-kicker">UNIT III · DRUGS AFFECTING THE CENTRAL NERVOUS SYSTEM</div>
    <div className="unit-note-heading"><span>CLASS {note.number}</span><h1>{note.title}</h1><p>{note.overview}</p></div>
    {note.sections.map((section,index)=><section className="unit-note-section" key={section.title}>
      <h2><span>{index+1}</span>{section.title}</h2>
      <ul>{section.points.map((point,i)=><li key={i}>{point}</li>)}</ul>
    </section>)}
    <div className="unit-note-warning"><ShieldAlert size={17}/><p><b>Educational reference only.</b> These concise notes support study and do not replace current prescribing information, clinical guidelines or professional judgement. Confirm drug-specific contraindications, doses and interactions from trusted references.</p></div>
    <div className="unit-note-footer"><BookOpen size={15}/> Pharmadesk · Unit III · Class {note.number}</div>
  </section>;
}
